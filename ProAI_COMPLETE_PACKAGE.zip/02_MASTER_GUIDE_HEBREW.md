# 🎮 המדריך האולטימטיבי — כל לחיצה, כל כפתור, כל פיקסל
## UEFN v39.50+ | מדריך למי שמעולם לא פתח את התוכנה

---

# 🖥️ פרק 1: התקנת UEFN

## 1.1 — התקנת Epic Games Launcher
1. פתח דפדפן (Chrome / Edge)
2. לך לכתובת: `www.epicgames.com`
3. בפינה ימנית עליונה לחץ **Download** (הורדה)
4. הורד את **Epic Games Launcher**
5. הפעל את הקובץ שהורדת (`EpicInstaller-xxx.msi`)
6. לחץ **Next** → **Install** → המתן → **Finish**
7. התוכנה תיפתח — אם יש לך חשבון Epic, כתוב מייל וסיסמה. אם אין — לחץ **Sign Up** וצור חשבון

## 1.2 — התקנת Fortnite (חובה — UEFN לא עובד בלי Fortnite!)
1. ב-Epic Games Launcher, לחץ על **Store** (חנות) בצד שמאל
2. בשורת החיפוש למעלה כתוב: `Fortnite`
3. לחץ על **Fortnite** בתוצאות
4. לחץ **Get** (קבל) — זה חינם
5. בחר מיקום התקנה → **Install** (התקן)
6. **המתן** — Fortnite גדול (~30-80 GB). זה לוקח זמן

## 1.3 — התקנת UEFN
1. ב-Epic Games Launcher, לחץ **Store** שוב
2. חפש: `UEFN` או `Unreal Editor for Fortnite`
3. לחץ על **Unreal Editor for Fortnite**
4. לחץ **Get** → **Install**
5. **המתן** — ~20 GB נוספים
6. אחרי שהתקנה נגמרת, תראה UEFN ב-**Library** (ספרייה) בצד שמאל

## 1.4 — פתיחת UEFN בפעם הראשונה
1. ב-Epic Games Launcher → **Library** (ספרייה)
2. מצא **Unreal Editor for Fortnite**
3. לחץ **Launch** (הפעל) — כפתור ירוק/כחול
4. **בפעם הראשונה:** ייתכן שיבקשו ממך:
   - לאשר תנאי שימוש → לחץ **Accept** (אשר)
   - לבחור הגדרות → השאר הכל כברירת מחדל → **OK**
5. UEFN ייטען. מופיע לוגו Epic ואז מסך הפתיחה

---

# 📂 פרק 2: יצירת פרויקט חדש — לחיצה אחרי לחיצה

## 2.1 — מסך הפתיחה (Project Browser)
כשנפתח UEFN, אתה רואה את **Project Browser** — מסך עם שני חלקים:
- **שמאל:** כפתורים — **Recent** (אחרונים), **Island Templates** (תבניות אי), **Feature Examples** (דוגמאות)
- **ימין:** תצוגה מקדימה של התבנית שנבחרה

## 2.2 — בחירת תבנית
1. **לחץ** על **Island Templates** בצד שמאל
2. תראה רשימת תבניות עם תמונות מקדימות
3. **גלול** ומצא תבנית שנקראת **Blank** (ריק) — יכולה להופיע גם כ-**Flat Grid** (רשת שטוחה)
   - **מה לחפש:** תמונה של אי ריק שטוח, בלי מבנים
   - **⚠️ אל תבחר** תבניות עם מבנים מוכנים כמו "Desert", "Medieval" וכו׳ — אנחנו רוצים לוח חלק
4. **לחץ פעם אחת** על **Blank** — תראה שהמסגרת סביבו הופכת לכחולה (=נבחר)

## 2.3 — שם הפרויקט
1. בתחתית המסך יש שדה טקסט שכתוב בו **Project Name** (שם פרויקט)
2. **לחץ** על השדה — הטקסט שבפנים ייבחר (יהפוך לכחול)
3. **כתוב:** `ProAI_TrainingMap`
   - **P** גדולה
   - **A** גדולה, **I** גדולה
   - קו תחתון `_` בין המילים (Shift+מקף)
   - **T** גדולה, **M** גדולה
   - **אין רווחים!**

## 2.4 — יצירה
1. לחץ על הכפתור **Create** (צור) — כפתור גדול בפינה ימנית תחתונה
2. **המתן 30-120 שניות** — תראה פס טעינה
3. כשנגמר — העורך נפתח ותראה את האי שלך ב-Viewport

## 2.5 — שמירה ראשונית
1. לחץ **Ctrl+S** (שתי מקשים ביחד: Ctrl ו-S)
2. אם קופץ חלון ששואל מה לשמור — לחץ **Save Selected** (שמור נבחרים)

---

# 🗺️ פרק 3: הכרת המסך — כל אזור בפירוט

## 3.1 — Viewport (חלון עולם — האזור הגדול באמצע)

**מה זה:** כאן אתה רואה את העולם שלך בתלת-מימד. כל מה שמונח בעולם נראה כאן.

**שליטה בעכבר:**
| פעולה | מה לעשות | מה קורה |
|---|---|---|
| סיבוב מצלמה | **לחץ והחזק ימני** + הזז עכבר | המצלמה מסתובבת |
| תנועה חופשית | **לחץ והחזק ימני** + **W/A/S/D** | מתקדם קדימה/שמאלה/אחורה/ימינה |
| למעלה/למטה | **לחץ והחזק ימני** + **E** (למעלה) / **Q** (למטה) | עולה/יורד |
| זום | **גלגלת עכבר** קדימה/אחורה | מתקרב/מתרחק |
| בחירת אובייקט | **לחיצה שמאלית** על אובייקט | מסגרת כתומה מופיעה סביבו |
| ביטול בחירה | **לחץ שמאלית** על שטח ריק | הבחירה מתבטלת |

**כלי עריכה — 3 מצבים (אותיות W, E, R):**
| מקש | מצב | מה עושה | איך נראה |
|---|---|---|---|
| **W** | Move (הזזה) | חצים אדום/ירוק/כחול — גרור כדי להזיז | 3 חצים צבעוניים |
| **E** | Rotate (סיבוב) | עיגולים צבעוניים — גרור כדי לסובב | 3 עיגולים |
| **R** | Scale (גודל) | קוביות צבעוניות — גרור כדי לשנות גודל | 3 קוביות |

**⚠️ חשוב:** כשאתה לוחץ W/E/R, הכלי משתנה. **תמיד תדע באיזה מצב אתה** — תסתכל על הגיזמו (הצורה) שמופיעה על האובייקט הנבחר.

**שורת הכלים של ה-Viewport (שורה עליונה בתוך ה-Viewport עצמו):**
- **Perspective** — לחץ כדי לשנות זווית מצלמה (Top, Front, Side)
- **Lit** — לחץ כדי לשנות מצב תאורה (Unlit = בלי צללים, Wireframe = רשת חוטים)
- **Show** — תפריט שמאפשר להפעיל/כבות שכבות תצוגה (כמו **Navigation** — ירוק ה-NavMesh)

## 3.2 — Content Browser (דפדפן תוכן — תחתית המסך)

**מה זה:** הספרייה שלך. כל דבר שקיים בפרויקט נמצא כאן — פרופס, מכשירים, סקינים, הקוד שלך.

**מבנה:**
- **שמאל:** עץ תיקיות. בשורש יש **Content** ו-**All** (הכל)
  - **Content** = הפרויקט שלך
  - **All** = כולל גם assets של Fortnite (ספריית פרופס ענקית)
- **ימין:** התוכן של התיקייה שנבחרה (אייקונים גדולים/קטנים)
- **למעלה שמאל:** **שורת חיפוש** — כתוב שם של asset ותמצא אותו

**פעולות נפוצות:**
| פעולה | מה לעשות |
|---|---|
| חיפוש asset | כתוב שם בשורת החיפוש |
| כניסה לתיקייה | **לחיצה כפולה** על תיקייה |
| חזרה אחורה | לחץ על **החץ השמאלי ←** בשורת הניווט |
| הנחת asset בעולם | **גרור** (לחץ שמאלי + הזז) מ-Content Browser אל ה-Viewport |
| יצירת תיקייה חדשה | **לחץ ימני** על שטח ריק → **New Folder** |
| יצירת asset חדש | **לחץ ימני** על שטח ריק → בחר מהתפריט |
| מחיקת asset | **לחץ ימני** על ה-asset → **Delete** |
| שכפול asset | **לחץ ימני** → **Duplicate** (או בחר + **Ctrl+D**) |
| שינוי שם | **לחץ ימני** → **Rename** (או לחץ איטי פעמיים על השם) |

**⚠️ טיפ חשוב:** אם אתה לא מוצא asset שיצרת — ודא שאתה **בתיקייה הנכונה**. לחץ על **Content** בעץ התיקיות בצד שמאל כדי לחזור לשורש.

## 3.3 — Outliner (רשימת אובייקטים — ימין למעלה)

**מה זה:** רשימת טקסט של **כל האובייקטים שמונחים בעולם**. 

**למה שימושי:** כשיש הרבה אובייקטים, קשה לבחור אחד ספציפי ב-Viewport. ב-Outliner אפשר פשוט ללחוץ על השם שלו.

**פעולות:**
| פעולה | מה לעשות |
|---|---|
| בחירת אובייקט | **לחץ** על שמו ב-Outliner — הוא ייבחר גם ב-Viewport |
| חיפוש | כתוב בשורת החיפוש בראש ה-Outliner |
| מחיקה | בחר אובייקט → לחץ **Delete** במקלדת |
| הצגה/הסתרה | לחץ על אייקון **העין** 👁 ליד השם |

## 3.4 — Details Panel (פאנל פרטים — ימין למטה)

**מה זה:** כשאתה **בוחר אובייקט** (ב-Viewport או ב-Outliner), כל ההגדרות שלו מופיעות כאן.

**מה יש בפנים:**

**Transform (מיקום/סיבוב/גודל):**
- **Location** — מיקום בעולם (X, Y, Z)
  - X = שמאל/ימין
  - Y = קדימה/אחורה
  - Z = למעלה/למטה (Z=0 = גובה הקרקע, Z=-5000 = מתחת לאדמה)
- **Rotation** — סיבוב (Roll, Pitch, Yaw) — במעלות
- **Scale** — גודל (1,1,1 = רגיל. 2,2,2 = כפול)

**איך משנים ערך:**
1. **לחץ** על המספר (למשל 0.0 ליד X)
2. **מחק** את המספר הישן
3. **כתוב** את המספר החדש
4. **לחץ Enter** — הערך נשמר והאובייקט זז

**Properties מיוחדות (מתחת ל-Transform):**
- כל device/prop יש לו properties ייחודיות
- **@editable** properties מה-Verse code שלנו מופיעות כאן!
- Properties עם **dropdown** (חץ למטה) מאפשרות לבחור מרשימה
- Properties עם **checkbox** (☐/☑) = כן/לא
- Properties עם **מספר** = ערך נומרי (float/int)

**⚠️ חשוב מאוד:**
- **אם ה-Details Panel ריק** — שום דבר לא נבחר. לחץ על אובייקט ב-Viewport
- **אם אתה לא רואה property מסוימת** — גלול למטה! ה-Details Panel ארוך ויש הרבה הגדרות
- **אפשר לחפש:** בראש ה-Details Panel יש **שורת חיפוש** — כתוב שם property

## 3.5 — תפריט עליון (Menu Bar — שורה הכי עליונה)

| תפריט | מה יש בפנים | מתי נשתמש |
|---|---|---|
| **File** | Save, Save All, Import, Exit | שמירה |
| **Edit** | Undo, Redo, Cut, Copy, Paste | עריכה בסיסית |
| **Build** | Build Navigation, Build All | בניית NavMesh |
| **Verse** | Verse Explorer, Build Verse Code | עבודה עם קוד |
| **Window** | Output Log, Content Browser, Outliner | פתיחת חלונות |

## 3.6 — Toolbar (סרגל כלים — מתחת לתפריט העליון)

שורה של כפתורים עם אייקונים. הכי חשובים:

| אייקון | שם | מה עושה |
|---|---|---|
| 💾 | **Save Current** | שומר את הרמה הנוכחית |
| ▶️ ירוק | **Launch Session** | מפעיל את המשחק לבדיקה! |
| 🔨 | **Build** | בונה תאורה/ניווט |

---

# 📝 פרק 4: פתיחת Verse Explorer ויצירת קבצים

## 4.1 — פתיחת Verse Explorer
1. תפריט עליון: לחץ על **Verse**
2. בתפריט שנפתח, לחץ על **Verse Explorer**
3. ייפתח **פאנל חדש** — בדרך כלל הוא נצמד לצד ימין, ליד ה-Outliner
4. **מה תראה:** עץ תיקיות קטן. בשורש:
   - שם הפרויקט שלך (למשל `ProAI_TrainingMap`)
   - תחתיו: **Content**

## 4.2 — יצירת קובץ Verse חדש
**חזור על השלבים האלה עבור כל אחד מ-35 הקבצים:**

### שלב 1: לחץ ימני
- ב-Verse Explorer, **לחץ ימני** על הכיתוב **Content**
- ייפתח תפריט קטן

### שלב 2: בחר Create New Verse File
- לחץ על **Create New Verse File** (צור קובץ Verse חדש)
- ייפתח **חלון קטן** עם כמה שדות

### שלב 3: בחר סוג (Template)
- תראה רשימה של templates (תבניות):
  - **Blank** — קובץ ריק
  - **NPC Behavior** — קובץ עם קוד NPC מוכן
  - **NPC Behavior Basic** — גרסה בסיסית של NPC
  - **Creative Device** — קובץ device ריק
  - ואולי עוד...

**מה לבחור:**
- **עבור כל הקבצים:** בחר **Blank** (ריק)
- **חריג אחד:** עבור `bot_behavior_base` — בחר **NPC Behavior Basic**
  - (זה מוודא שה-class structure הנכון נוצר)
  - **אבל!** אחרי שנוצר — תמחק הכל ותדביק את הקוד מהזיפ

### שלב 4: כתוב שם
- בשדה **File Name** (שם קובץ):
  - כתוב את השם **בדיוק** כמו שמופיע ברשימה
  - **אותיות קטנות בלבד** (lowercase)
  - **קווים תחתונים** בין מילים (underscore: `_`)
  - **בלי** `.verse` בסוף — UEFN מוסיף אוטומטית!
  - דוגמה: `event_bus` (לא `Event_Bus`, לא `event_bus.verse`)

### שלב 5: לחץ Create
- לחץ על **Create** (צור)
- **מה קורה עכשיו:**
  - VS Code (עורך קוד) נפתח אוטומטית עם הקובץ החדש
  - ב-Verse Explorer תראה את הקובץ ברשימה תחת Content

### ⚠️ אם VS Code לא נפתח:
- לחץ **כפול** על הקובץ ב-Verse Explorer — זה יפתח אותו ב-VS Code
- אם עדיין לא — לחץ ימני על הקובץ → **Open in Editor**

## 4.3 — העתקת קוד מהזיפ לתוך הקובץ

### שלב 1: פתח את הקובץ מהזיפ
1. לך ל-Windows Explorer (סייר הקבצים)
2. מצא את התיקייה שחילצת מהזיפ (`Verse_Code`)
3. מצא את הקובץ המתאים (למשל `event_bus.verse`)
4. **לחץ ימני** על הקובץ → **Open with** (פתח באמצעות) → **Notepad** (פנקס רשימות)
   - אם Notepad לא מופיע: **Open with** → **Choose another app** → מצא **Notepad** → סמן **Always use** → **OK**

### שלב 2: העתק הכל מ-Notepad
1. ב-Notepad, לחץ **Ctrl+A** (בחר הכל) — כל הטקסט ייבחר (יהפוך לכחול)
2. לחץ **Ctrl+C** (העתק)

### שלב 3: הדבק ב-VS Code
1. חזור ל-VS Code (Alt+Tab או לחץ עליו בשורת המשימות)
2. ב-VS Code, לחץ **Ctrl+A** (בחר הכל — כדי למחוק מה שכבר שם)
3. לחץ **Ctrl+V** (הדבק) — הקוד מהזיפ מחליף את מה שהיה
4. לחץ **Ctrl+S** (שמור)

### שלב 4: ודא ששמרת
- בכותרת הלשונית (tab) של VS Code, אם יש **נקודה לבנה** ● ליד שם הקובץ — הקובץ **לא שמור**
- אחרי Ctrl+S, הנקודה נעלמת = שמור ✅

### שלב 5: סגור את ה-tab ב-VS Code (אופציונלי)
- לחץ על ה-**X** בלשונית כדי לסגור
- או השאר פתוח ועבור לקובץ הבא

## 4.4 — סדר מומלץ ליצירת הקבצים (למניעת שגיאות)

**⚠️ צור אותם בסדר הזה!** חלק מהקבצים תלויים באחרים. אם תיצור בסדר לא נכון, יהיו שגיאות (שייפתרו כשהקובץ החסר ייווצר).

**🟢 קבוצה 1 — ללא תלויות (צור ראשון):**
```
1.  metric_definitions
2.  bot_difficulty_profile
3.  data_schema_v1
4.  data_schema_v2
5.  feedback_templates
```

**🟡 קבוצה 2 — תלויים בקבוצה 1:**
```
6.  event_bus
7.  bot_navigation
8.  bot_focus_aim
9.  bot_combat_state_machine
10. bot_weapon_controller
11. build_prop_spawner
12. build_animation_sync
13. elo_calculator
14. difficulty_mapper
15. predictive_advisor
16. session_aggregator
17. data_validator
18. migration_v1_to_v2
19. inventory_controller
```

**🟠 קבוצה 3 — תלויים בקבוצה 2:**
```
20. arena_controller
21. build_pool_manager
22. edit_state_manager
23. analytics_engine
24. persistence_manager
25. coach_controller
26. shop_manager
27. xp_reward_system
28. cosmetic_applicator
29. hud_binding
30. scorecard_renderer
```

**🔴 קבוצה 4 — תלויים בקבוצה 3 (צור אחרון):**
```
31. game_manager
32. bot_behavior_base  ← (זכור: NPC Behavior Basic template)
33. build_sequence_choreographer
34. coach_game_bridge
35. shop_ui_controller
```

## 4.5 — בניית Verse (קומפילציה)

### מה זה
בנייה = הפיכת הקוד שכתבת ל"דבר שרץ". בלי בנייה, הקוד הוא סתם טקסט.

### איך עושים
1. חזור ל-UEFN (Alt+Tab מ-VS Code)
2. תפריט עליון: **Verse** → **Build Verse Code**
   - **קיצור:** Ctrl+Shift+B (שלושה מקשים ביחד)
3. **המתן 30 שניות עד 3 דקות**
4. הסתכל בתחתית המסך — ייפתח **Output Log** אוטומטית

### מה לחפש ב-Output Log
- **✅ הצלחה:** תראה `Verse: Build succeeded` (או `Build completed successfully`)
- **❌ כשלון:** תראה `Build failed` ושורות אדומות עם שגיאות

### מה לעשות אם Build failed (נכשל)

**שגיאה: `Unknown identifier 'XXX'`**
- **משמעות:** הקוד מנסה להשתמש במשהו שלא קיים
- **סיבה:** חסר קובץ (הקובץ שמגדיר את XXX עדיין לא נוצר)
- **פתרון:** ודא שכל 35 הקבצים קיימים. בדוק שהשם כתוב נכון

**שגיאה: `Unexpected token` או `Expected indentation`**
- **משמעות:** בעיית פורמט בקוד
- **סיבה:** טאבים במקום רווחים
- **פתרון:** 
  1. פתח את הקובץ הבעייתי ב-VS Code
  2. לחץ **Ctrl+H** (חיפוש והחלפה)
  3. בשדה **Search** (חיפוש): לחץ על כפתור **.*☐** (regex) ואז כתוב `\t`
  4. בשדה **Replace** (החלפה): כתוב 4 רווחים (לחץ space 4 פעמים)
  5. לחץ **Replace All** (החלף הכל)
  6. שמור (Ctrl+S)

**שגיאה: `Duplicate definition`**
- **משמעות:** שני קבצים מגדירים אותו דבר
- **סיבה:** יצרת קובץ פעמיים, או שקובץ ישן מ-Phase 0 עדיין קיים
- **פתרון:** ב-Verse Explorer, מצא את הכפילות ומחק אותה (לחץ ימני → Delete)

---

# 🏟️ פרק 5: בניית הארנה — שלב אחרי שלב

## 5.1 — חיפוש אריח רצפה

### דרך 1: חיפוש ב-Content Browser
1. ב-Content Browser (תחתית המסך), מצא את **שורת החיפוש**
   - היא בפינה השמאלית העליונה של ה-Content Browser
   - יש בה אייקון זכוכית מגדלת 🔍
2. **לחץ** על שורת החיפוש
3. **כתוב:** `Gallery Floor` (או `Platform` או `Floor Tile`)
4. המתן שנייה — תוצאות יופיעו
5. תראה כמה אייקונים. חפש אריח שנראה כמו **רצפה שטוחה** — לא מבנה שלם, לא חפץ מעוצב, סתם **משטח שטוח**

### דרך 2: דפדוף בספריית Fortnite
1. ב-Content Browser, בעץ התיקיות שמשמאל, לחץ על **All** (הכל)
2. חפש תיקייה שנקראת **Fortnite** → **Galleries** → חפש Gallery עם רצפות
3. בחר רצפה שמתאימה

### ⚠️ אם לא מוצא רצפה מתאימה:
- חפש `Grid Island` — לפעמים יש רצפת ברירת מחדל
- או חפש `Wood Floor` / `Stone Floor`
- **הדבר הכי חשוב:** שהאריח יהיה **שטוח** ושיש לו **Collision** (התנגשות) — אחרת NavMesh לא ייווצר

## 5.2 — הנחת הרצפה בעולם
1. **מצאת אריח?** מצוין.
2. **גרור אותו:** לחץ שמאלי על האייקון ב-Content Browser, **החזק**, ו**גרור** ל-Viewport (למרכז המסך)
3. **שחרר** — האריח מופיע בעולם

## 5.3 — מיקום הרצפה
1. **בחר** את האריח ב-Viewport (לחץ עליו — מסגרת כתומה)
2. **ב-Details Panel** (ימין), מצא את **Transform**:
   - אם Transform מקופל (מוסתר) — לחץ על **החץ ▶** לידו כדי לפתוח
3. שנה **Location** (מיקום):
   - **X:** `0`
   - **Y:** `0`
   - **Z:** `0` (חשוב! זה גובה הקרקע)
   
   **איך משנים:** לחץ על המספר → מחק → כתוב חדש → Enter

## 5.4 — הגדלת הרצפה
1. עם האריח נבחר, ב-Details Panel → **Transform** → **Scale** (גודל):
   - **X:** `20`
   - **Y:** `20`
   - **Z:** `1` (לא משנים גובה)
2. לחץ **Enter** אחרי כל שינוי

**⚠️ אם הרצפה עפה לאחר השינוי:**
- בדוק ש-Location → Z עדיין 0
- אם לא — שנה חזרה ל-0

## 5.5 — בניית NavMesh (שטח ניווט)
1. תפריט עליון: **Build** → **Build Navigation**
   - אם אין כזו אפשרות: **Build** → **Build All** (בונה הכל — כולל ניווט)
2. **המתן** כמה שניות (תראה פס התקדמות קטן בתחתית)

## 5.6 — בדיקה ויזואלית של NavMesh
1. ב-Viewport (לא בתפריט הראשי! בתוך ה-Viewport עצמו), חפש בשורה העליונה כפתור שכתוב **Show**
2. לחץ על **Show** → תפריט נפתח
3. חפש **Navigation** → ודא שמסומן ✓ (לחץ עליו אם לא)
4. **תוצאה צפויה:** שכבה ירוקה חצי-שקופה מכסה את כל הרצפה
5. **אם אין ירוק:**
   - הרצפה לא מתאימה ל-NavMesh
   - נסה רצפה אחרת
   - או: ודא שהרצפה מספיק גדולה (Scale 20,20,1 לפחות)

## 5.7 — הנחת קירות גבול
1. ב-Content Browser חפש: `Wall` (קיר)
2. מצא קיר פשוט (לא חלון, לא דלת — קיר מלא)
3. **גרור** ל-Viewport
4. **מקם** בקצה הרצפה:
   - Location X = מיקום הקצה (תלוי בגודל הרצפה שלך)
   - Z = 0 (גובה קרקע)
5. **שכפל:** עם הקיר נבחר, לחץ **Ctrl+D**
6. **הזז** את השכפול לקצה הנגדי
7. חזור עוד 2 פעמים = **4 קירות סביב הארנה**

---

# 🤖 פרק 6: הגדרת NPC Character Definition

## 6.1 — יצירת ה-"תעודת זהות" של הבוט

### שלב 1: ודא שאתה בתיקייה הנכונה
1. ב-Content Browser, לחץ על **Content** בעץ התיקיות שמשמאל
2. **ודא שאתה בתיקיית Content הראשית** — לא בתוך תתי-תיקייה כלשהי!
   - בשורת הניווט שלמעלה צריך לכתוב: **Content** (ולא Content/Blueprints/NPCs...)

### שלב 2: לחץ ימני
1. **לחץ ימני** על **שטח ריק** ב-Content Browser (לא על קובץ — על הרקע!)
2. ייפתח **תפריט הקשר** (Context Menu) — תפריט גדול עם הרבה אפשרויות

### שלב 3: נווט בתפריט
1. תפריט ארוך. גלול או חפש: **Artificial Intelligence**
   - ⚠️ שם האפשרות בגרסאות שונות:
   - אולי **Artificial Intelligence** → **NPC Character Definition**
   - אולי **AI** → **NPC Character Definition**
   - אולי **Create Advanced Asset** → **Artificial Intelligence** → **NPC Character Definition**
2. **לחץ** על **NPC Character Definition**

### שלב 4: מתן שם
1. קובץ חדש מופיע ב-Content Browser עם שם ברירת מחדל (מודגש, מוכן לעריכה)
2. **כתוב:** `BP_CombatBot_Base`
3. **לחץ Enter**

## 6.2 — הגדרת הבוט מבפנים

### שלב 1: פתיחה
1. **לחץ כפול** על `BP_CombatBot_Base` ב-Content Browser
2. ייפתח **חלון הגדרות NPC** — חלון חדש עם כמה לשוניות/סקציות

### שלב 2: בחירת גוף (Body / Character Skin)
1. חפש סקציה שנקראת **Body**, **Character**, **Appearance**, או **Outfit**
2. לחץ על ה-dropdown (חץ למטה) או על כפתור **Browse** (עיין)
3. תראה רשימה של סקינים — **בחר כל אחד שמוצא חן בעיניך**
4. זה רק מראה חיצוני — לא משפיע על הביצועים

### שלב 3: Behavior Type (⚠️ הכי חשוב!)
1. חפש שדה שנקרא **Behavior Type**, **NPC Type**, או **Base Behavior**
2. תראה dropdown עם אפשרויות כמו:
   - **Guard** (שומר)
   - **Wildlife** (חיות בר)
   - **Custom** (מותאם)
3. **בחר: Guard** ← ⚠️ קריטי!
   - **Guard = הבוט יורה אוטומטית כשרואה אויב**
   - Custom = הבוט לא יירה בלי קוד נוסף
   - Wildlife = הבוט יתנהג כמו חיה

### שלב 4: נשק
1. חפש סקציה שנקראת **Equipment**, **Items**, **Loadout**, או **Weapon**
2. אם יש dropdown: בחר **Pump Shotgun** או **Shotgun**
3. אם אין שדה כזה — לא נורא! Guard-type מקבל נשק מובנה

### שלב 5: Behavior Script (⚠️ חשוב מאוד!)
1. חפש שדה שנקרא **Behavior Script** או **NPC Behavior Script Override**
2. לחץ על ה-dropdown (חץ למטה)
3. תראה רשימה. **חפש:** `bot_behavior_base`
4. **בחר אותו**

**⚠️ אם `bot_behavior_base` לא מופיע ברשימה:**
- סגור את חלון ההגדרות
- ב-UEFN: **Verse → Build Verse Code** (Ctrl+Shift+B)
- חכה ל-Build succeeded
- פתח שוב את `BP_CombatBot_Base`
- עכשיו הוא אמור להופיע

### שלב 6: שמירה
1. בחלון ההגדרות, חפש כפתור **Save** בפינה שמאלית עליונה
2. לחץ **Save**
3. **אם אין כפתור Save בחלון:** לחץ **Ctrl+S** — זה שומר הכל

## 6.3 — הנחת NPC Spawner

### שלב 1: מציאה
1. ב-Content Browser, כתוב בחיפוש: `NPC Spawner`
2. **⚠️ בדוק:** תראה כמה תוצאות. חפש את זה שכתוב **NPC Spawner** (בדיוק)
   - **לא** `Guard Spawner` (זה מכשיר אחר, ישן יותר)
   - **לא** `Creature Spawner` (לחיות בר)
   - **לא** `Wildlife Spawner`
   - ספציפית: **NPC Spawner**

### שלב 2: הנחה
1. **גרור** מ-Content Browser ל-Viewport
2. שחרר — ה-NPC Spawner מופיע בעולם (נראה כמו הולוגרמה כחולה של דמות)

### שלב 3: מיקום
1. הזז (W + גרירה, או שנה Location ב-Details Panel):
   - מקם **במרכז הארנה** — או בצד אחד, כ-8 אריחים מהשחקן
   - **Z = 0** (על הרצפה)

### שלב 4: הגדרות NPC Spawner
1. **בחר** את ה-NPC Spawner ב-Viewport
2. ב-**Details Panel** (ימין), חפש ושנה:

**NPC Character Definition:**
1. חפש שדה עם השם הזה
2. לחץ על ה-dropdown
3. בחר: `BP_CombatBot_Base`

**Spawn on Game Start:**
1. חפש שדה זה — ייתכן שייראה כ-checkbox (☐) או dropdown
2. שנה ל: **No** / **Disabled** / **כבוי** / **uncheck ☐**
3. **למה:** ה-game_manager שלנו שולט מתי הבוט מופיע

**Auto Respawn:**
1. חפש שדה זה
2. שנה ל: **No** / **Disabled**

**Max Spawn Count:**
1. חפש שדה זה
2. שנה ל: **1**

3. **שמור:** Ctrl+S

---

# 📍 פרק 7: Player Spawner, נשק, ו-Island Settings

## 7.1 — Player Spawner

### חיפוש
1. ב-Content Browser: `Player Spawner` או `Player Spawn Pad`
2. מצא device עם אייקון של דמות + חץ כלפי מטה

### הנחה
1. **גרור** ל-Viewport
2. מקם **בקצה הארנה** — הרחק מה-NPC Spawner
3. מרחק מומלץ: כ-2000 יחידות (שנה Location → X או Y)

### כיוון
1. בחר את ה-Player Spawner
2. לחץ **E** (מצב סיבוב)
3. גרור את **העיגול הכחול** (ציר Z) כך שהחץ **מצביע לכיוון ה-NPC Spawner**
4. לחץ **W** לחזור למצב הזזה

## 7.2 — Item Granter (נשק לשחקן)

### חיפוש
1. ב-Content Browser: `Item Granter`

### הנחה
1. **גרור** ל-Viewport — ליד ה-Player Spawner

### הגדרות
1. בחר את ה-Item Granter
2. ב-Details Panel:
   - **Item Definition / Item to Grant:** לחץ dropdown → חפש `Pump Shotgun` → בחר
   - **Number of Items:** `1`
   - **Grant on Game Start:** **Enabled** / **Yes** / **☑**

## 7.3 — Island Settings

### מציאה
1. ב-**Outliner** (ימין למעלה), חפש: `IslandSettings`
   - אם לא מוצא: כתוב `Island` בשורת החיפוש של ה-Outliner
2. **לחץ** עליו — ההגדרות יופיעו ב-Details Panel

### הגדרות
1. ב-Details Panel, חפש **User Options** → **Game Rules** (או חפש בחיפוש של Details)
2. **Down But Not Out:** שנה ל-**Off** (כבוי)
3. **Player Respawn:** בחר **Respawn After Delay**

---

# 🔧 פרק 8: הנחת Devices בסצנה — שלב אחרי שלב

## 8.1 — למה צריך להניח אותם
כל `creative_device` בקוד שלנו **חייב** להיות כאובייקט פיזי בסצנה. בלי זה, הקוד לא ירוץ.

## 8.2 — איך מוצאים אותם
אחרי **Build Verse** מוצלח:
1. ב-Content Browser, ודא שאתה ב-**Content** (תיקייה ראשית)
2. תראה **קוביות כחולות** — אלה ה-device assets שנוצרו מהקוד
3. אם לא רואה — כתוב את שם ה-device בחיפוש

## 8.3 — הנחה של כל device
**לכל אחד מ-16 ה-devices:**
1. חפש אותו ב-Content Browser
2. **גרור** ל-Viewport
3. מקם **בפינת הארנה** (כולם בצד אחד — מסודר)
4. **לא משנה** בדיוק איפה — הם בלתי נראים במשחק

**הרשימה המלאה — גרור כל אחד בנפרד:**

| # | חפש ב-Content Browser | גרור ל-Viewport |
|---|---|---|
| 1 | `event_bus` | ✅ |
| 2 | `arena_controller` | ✅ |
| 3 | `game_manager` | ✅ |
| 4 | `build_pool_manager` | ✅ |
| 5 | `build_sequence_choreographer` | ✅ |
| 6 | `edit_state_manager` | ✅ |
| 7 | `analytics_engine` | ✅ |
| 8 | `coach_controller` | ✅ |
| 9 | `coach_game_bridge` | ✅ |
| 10 | `shop_manager` | ✅ |
| 11 | `shop_ui_controller` | ✅ |
| 12 | `xp_reward_system` | ✅ |
| 13 | `cosmetic_applicator` | ✅ |
| 14 | `hud_binding` | ✅ |
| 15 | `scorecard_renderer` | ✅ |
| 16 | `persistence_manager` | ✅ |

**שמור: Ctrl+S**

---

# 🔌 פרק 9: חיווט @editable — החיבור בין Devices

## 9.0 — מה זה חיווט ואיך עושים

**ההסבר:** כל device יש לו "שקעים" שצריך לחבר ל-devices אחרים. ה"שקעים" האלה נקראים **@editable** ומופיעים ב-Details Panel.

**שלבי החיווט (זהים לכל חיווט):**
1. **בחר** device ב-Viewport (לחץ עליו — מסגרת כתומה)
2. **ב-Details Panel** (ימין), **גלול למטה** — חפש את השם של ה-property
3. ליד ה-property יש **dropdown** (חץ למטה ▼) — לחץ עליו
4. תיפתח **רשימה** של כל ה-devices שבסצנה
5. **בחר** את ה-device הנכון מהרשימה
6. הערך ישתנה — עכשיו הם מחוברים

**⚠️ אם ה-dropdown ריק (אין מה לבחור):**
- ה-device שאתה מחפש **לא מונח בסצנה** — חזור לפרק 8 ותוודא שהנחת אותו
- או: בנה Verse מחדש (Ctrl+Shift+B)

## 9.1 — game_manager
1. **ב-Viewport**, לחץ על ה-device של **game_manager** (או מצא אותו ב-Outliner)
2. **ב-Details Panel**, חפש:

**EventBus:**
- לחץ dropdown ▼
- בחר: **event_bus** (מהרשימה)

**ArenaCtrl:**
- לחץ dropdown ▼  
- בחר: **arena_controller**

**LobbyWaitSeconds** (מספר, לא dropdown):
- לחץ על המספר → מחק → כתוב `2` → Enter
  
**CountdownSeconds:**
- שנה ל: `2`

**RoundDurationSeconds:**
- שנה ל: `15` (לבדיקה — אחר כך תחזיר ל-60)

**PostRoundDisplaySeconds:**
- שנה ל: `2`

## 9.2 — arena_controller
1. **בחר** את **arena_controller** ב-Viewport
2. ב-Details Panel:

**EventBus** → dropdown → בחר **event_bus**

**BotSpawner** → dropdown → בחר את ה-**NPC Spawner** (⚠️ זה ה-NPC Spawner device, לא BP_CombatBot_Base! חפש את השם שנראה כמו "NPC Spawner" או "NPC_Spawner")

**PlayerSpawnRef** → dropdown → בחר את ה-**Player Spawner** (ה-device שמהנחת בפרק 7.1)

## 9.3 — analytics_engine
1. בחר **analytics_engine**
2. **EventBus** → dropdown → **event_bus**

## 9.4 — coach_controller
1. בחר **coach_controller**
2. **EventBus** → dropdown → **event_bus**

## 9.5 — coach_game_bridge
1. בחר **coach_game_bridge**
2. **EventBus** → dropdown → **event_bus**
3. **AnalyticsRef** → dropdown → **analytics_engine**
4. **ArenaCtrl** → dropdown → **arena_controller**

## 9.6 — hud_binding
1. בחר **hud_binding**
2. **EventBus** → dropdown → **event_bus**
3. **AnalyticsRef** → dropdown → **analytics_engine**

## 9.7 — scorecard_renderer
1. בחר **scorecard_renderer**
2. **EventBus** → dropdown → **event_bus**
3. **AnalyticsRef** → dropdown → **analytics_engine**

## 9.8 — build_sequence_choreographer
1. בחר **build_sequence_choreographer**
2. **PoolManager** → dropdown → **build_pool_manager**

## 9.9 — shop_ui_controller
1. בחר **shop_ui_controller**
2. **ShopMgr** → dropdown → **shop_manager**
3. **PersistMgr** → dropdown → **persistence_manager**

## 9.10 — סיכום חיווטים
| Device | Property | מחובר ל |
|---|---|---|
| game_manager | EventBus | event_bus |
| game_manager | ArenaCtrl | arena_controller |
| arena_controller | EventBus | event_bus |
| arena_controller | BotSpawner | NPC Spawner (device) |
| arena_controller | PlayerSpawnRef | Player Spawner (device) |
| analytics_engine | EventBus | event_bus |
| coach_controller | EventBus | event_bus |
| coach_game_bridge | EventBus | event_bus |
| coach_game_bridge | AnalyticsRef | analytics_engine |
| coach_game_bridge | ArenaCtrl | arena_controller |
| hud_binding | EventBus | event_bus |
| hud_binding | AnalyticsRef | analytics_engine |
| scorecard_renderer | EventBus | event_bus |
| scorecard_renderer | AnalyticsRef | analytics_engine |
| build_sequence_choreographer | PoolManager | build_pool_manager |
| shop_ui_controller | ShopMgr | shop_manager |
| shop_ui_controller | PersistMgr | persistence_manager |

**סה"כ: 17 חיבורים**

**שמור: Ctrl+S**

---

# 🧱 פרק 10: Pool Props מתחת לאדמה

## 10.1 — מה צריך

| סוג | חיפוש | כמות עותקים |
|---|---|---|
| קיר | `Wood Wall` או `Wall Gallery` | **12** |
| רצפה | `Wood Floor` או `Floor Piece` | **6** |
| רמפה | `Ramp` או `Stair` | **4** |
| קונוס | `Pyramid` או `Cone` | **4** |
| **סה"כ** | | **26** |

## 10.2 — תהליך (זהה לכל סוג)

### קירות (12 עותקים):
1. חפש `Wood Wall` ב-Content Browser
2. **גרור** ל-Viewport
3. **בחר** את הקיר → Details Panel → **Location Z** → שנה ל: **`-5000`**
4. הקיר "נעלם" — הוא מתחת לאדמה ✅
5. **עם הקיר עדיין נבחר**, לחץ **Ctrl+D** (שכפול)
6. הזז את השכפול קצת (כדי שלא יהיו באותו מיקום מדויק): שנה X ל-100, 200, 300... (לא חייב, אבל מקל על הזיהוי)
7. **חזור:** Ctrl+D עוד 10 פעמים (סה"כ 12 קירות)

### רצפות (6 עותקים):
8. חפש `Wood Floor` → גרור → Z=-5000 → שכפל 5 פעמים

### רמפות (4 עותקים):
9. חפש `Ramp` → גרור → Z=-5000 → שכפל 3 פעמים

### קונוסים (4 עותקים):
10. חפש `Pyramid` / `Cone` → גרור → Z=-5000 → שכפל 3 פעמים

## 10.3 — חיווט ל-build_pool_manager

1. **בחר** את `build_pool_manager` ב-Viewport (או מצא ב-Outliner)
2. ב-**Details Panel**, חפש **WallProps** — תראה מערך (array) ריק

### הוספת entries למערך:
1. ליד **WallProps** יש כפתור **+** (פלוס) — **לחץ עליו**
2. נוצר entry חדש (שורה) עם dropdown
3. **לחץ** על ה-dropdown → תראה רשימה של כל ה-props בסצנה
4. **בחר** אחד מ-12 הקירות שהנחת
5. **חזור:** לחץ **+** שוב → בחר קיר אחר
6. **12 פעמים** — כל entry מצביע על **קיר שונה**

**⚠️ חשוב: כל entry חייב להצביע על prop אחר. אם שני entries מצביעים על אותו prop — באגים!**

7. חזור על התהליך עם:
   - **FloorProps** → **+** × 6 → בחר 6 רצפות שונות
   - **RampProps** → **+** × 4 → בחר 4 רמפות שונות
   - **ConeProps** → **+** × 4 → בחר 4 קונוסים שונים

**שמור: Ctrl+S**

---

# ▶️ פרק 11: הבדיקה הגדולה!

## 11.1 — בנייה אחרונה
1. **Verse → Build Verse Code** (Ctrl+Shift+B)
2. ודא: **Build succeeded** ✅

## 11.2 — שמירת הכל
1. **File → Save All** (או Ctrl+S)

## 11.3 — הפעלה
1. בסרגל הכלים, מצא **Launch Session** (כפתור ירוק ▶️)
2. **לחץ** עליו
3. אם קופץ חלון שמירה → **Save**
4. **Fortnite נפתח** — מסך טעינה → אתה מופיע על האי

## 11.4 — מה אמור לקרות (צעד אחר צעד)
1. **0-2 שניות:** אתה מופיע. מקבל נשק (שוטגאן)
2. **2-4 שניות:** בלוג תראה "LOBBY" ← ה-game_manager מתחיל
3. **4-6 שניות:** "COUNTDOWN" ← הבוט מופיע ליד ה-NPC Spawner
4. **6-9 שניות:** ספירה 3...2...1... "FIGHT!"
5. **הבוט מתחיל לרוץ לעברך!** 🏃
6. **הבוט מכוון אליך** תוך כדי ריצה 🎯
7. **כשהוא קרוב — הוא יורה!** 💥
8. **אם אתה הורג אותו** → "PLAYER WIN" → הסבב נגמר מיד
9. **אם הוא הורג אותך** → "BOT WIN"
10. **אחרי הפסקה** → איפוס → אתה חוזר לנקודת ההתחלה → הבוט מופיע מחדש → סבב חדש

## 11.5 — בדיקת Output Log
1. לחץ **Alt+Tab** כדי לחזור ל-UEFN
2. חפש **Output Log** — חלונית בתחתית המסך
3. **אם לא רואה אותה:** תפריט **Window** → **Output Log**
4. חפש הודעות:
```
GAME_MGR: Pro AI Training Map — ONLINE
BOT: Spawned — initializing combat behavior.
BOT: Target player found. Engaging.
BOT: Chase loop started.
```

## 11.6 — סיום הבדיקה
1. ב-Fortnite: לחץ **Escape** → **End Game** (סיום משחק)
2. חזור ל-UEFN

## 11.7 — אם הבוט לא מופיע / לא זז / לא יורה — ראה פרק 12

---

# ❗ פרק 12: פתרון כל בעיה אפשרית

| # | בעיה | מה לבדוק | מה לעשות |
|---|---|---|---|
| 1 | Build Verse נכשל | שגיאות ב-Output Log | קרא את השגיאה. בדוק שכל 35 קבצים קיימים ושמות נכונים |
| 2 | Device לא מופיע ב-Content Browser | Verse לא נבנה | Ctrl+Shift+B ← Build Verse |
| 3 | הבוט לא מופיע בכלל | NPC Spawner לא מוגדר | בדוק: NPC Character Definition = BP_CombatBot_Base |
| 4 | הבוט מופיע ולא זז | אין NavMesh | Build → Build Navigation. בדוק Show → Navigation (ירוק) |
| 5 | הבוט זז אבל לא יורה | Behavior Type לא Guard | פתח BP_CombatBot_Base → שנה Behavior Type ל-Guard |
| 6 | הבוט זז וקופא | NavigateTo נתקע | בדוק שהרצפה שלמה, אין חורים, NavMesh מכסה הכל |
| 7 | הסבב לא נגמר כשהורגים | חיווט חסר | ודא arena_controller → BotSpawner = NPC Spawner |
| 8 | השחקן לא חוזר למקום | PlayerSpawnRef לא מחווט | ודא arena_controller → PlayerSpawnRef = Player Spawner |
| 9 | אין נשק לשחקן | Item Granter לא מוגדר | בדוק Item Granter → Grant on Game Start = Enabled |
| 10 | @editable ריק | Device לא בסצנה | גרור את ה-device ל-Viewport |
| 11 | "Unknown identifier" | קובץ חסר | בדוק שכל 35 קבצים נוצרו |
| 12 | "Duplicate definition" | קובץ כפול | מחק את הכפילות ב-Verse Explorer |
| 13 | NPC Spawner מופיע כ-asset ולא כ-device | גררת את הלא-נכון | חפש NPC Spawner **device** (עם אייקון device) — לא NPC Character Definition |
| 14 | הכל עובד אבל אחרי סבב 1 הבוט לא חוזר | Enable/Disable bug | סגור UEFN לגמרי, פתח מחדש, נסה שוב |
| 15 | Pool props לא מופיעים כשהבוט "בונה" | מערכים לא מלאים | בדוק build_pool_manager → WallProps/FloorProps/RampProps/ConeProps |

---

# 🎯 פרק 13: צ'קליסט סופי — סמן כל שורה

```
שלב 0 — תשתית:
[ ] UEFN מותקן ופועל
[ ] Fortnite מותקן
[ ] פרויקט ProAI_TrainingMap נוצר
[ ] uplugin: EnableVerseAssetReflection = true

שלב 1 — קוד:
[ ] 35 קבצי Verse נוצרו ב-Verse Explorer (Content root)
[ ] תוכן כל קובץ הודבק מהזיפ
[ ] Build Verse = succeeded (אפס שגיאות)

שלב 2 — ארנה:
[ ] רצפה מונחת (Scale 20,20,1)
[ ] Build Navigation בוצע
[ ] NavMesh ירוק מכסה את הרצפה
[ ] קירות גבול (אופציונלי)

שלב 3 — בוט:
[ ] BP_CombatBot_Base נוצר ב-Content root
[ ] Behavior Type = Guard
[ ] Behavior Script = bot_behavior_base
[ ] NPC Spawner מונח
[ ] NPC Spawner → NPC Character Definition = BP_CombatBot_Base
[ ] NPC Spawner → Spawn on Game Start = Disabled

שלב 4 — שחקן:
[ ] Player Spawner מונח ומכוון
[ ] Item Granter מונח (Pump Shotgun, Grant on Game Start)
[ ] Island Settings: DBNO = Off

שלב 5 — Devices:
[ ] 16 creative devices מונחים בסצנה

שלב 6 — חיווטים:
[ ] game_manager → EventBus + ArenaCtrl
[ ] arena_controller → EventBus + BotSpawner + PlayerSpawnRef
[ ] analytics_engine → EventBus
[ ] coach_controller → EventBus
[ ] coach_game_bridge → EventBus + AnalyticsRef + ArenaCtrl
[ ] hud_binding → EventBus + AnalyticsRef
[ ] scorecard_renderer → EventBus + AnalyticsRef
[ ] build_sequence_choreographer → PoolManager
[ ] shop_ui_controller → ShopMgr + PersistMgr

שלב 7 — Pool:
[ ] 12 קירות ב-Z=-5000
[ ] 6 רצפות ב-Z=-5000
[ ] 4 רמפות ב-Z=-5000
[ ] 4 קונוסים ב-Z=-5000
[ ] build_pool_manager → WallProps (12 entries)
[ ] build_pool_manager → FloorProps (6 entries)
[ ] build_pool_manager → RampProps (4 entries)
[ ] build_pool_manager → ConeProps (4 entries)

שלב 8 — בדיקה:
[ ] Build Verse אחרון = succeeded
[ ] File → Save All
[ ] Launch Session
[ ] הבוט מופיע
[ ] הבוט רודף
[ ] הבוט יורה
[ ] חיסול בוט = PLAYER WIN מיידי
[ ] חיסול שחקן = BOT WIN מיידי
[ ] טיימר = DRAW
[ ] 3+ סבבים רצים ברציפות
[ ] Output Log ללא שגיאות
```

**כשכל השורות מסומנות — המפה פעילה! 🎉**
