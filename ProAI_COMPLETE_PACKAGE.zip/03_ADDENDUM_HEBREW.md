# 📎 נספח — כל מה שחסר במדריך הראשי
## פריטים מתקדמים: מאמן AI, ווריאנטים, ממשק משתמש, עריכות קיר

> **מתי לעשות את זה:** אחרי שהמפה הבסיסית עובדת (בוט רודף ויורה, סבבים רצים)  
> **חיוניות:** הפריטים מסומנים 🔴 חובה / 🟡 מומלץ / 🟢 אופציונלי-פוליש

---

# 🟡 1. המאמן AI (Coach NPC)

## 1.1 — יצירת NPC Character Definition למאמן
1. ב-**Content Browser** → ודא שאתה בתיקיית Content הראשית
2. **לחץ ימני** על שטח ריק → **Artificial Intelligence** → **NPC Character Definition**
3. שם: `BP_CoachNPC`
4. **לחץ כפול** לפתיחה
5. הגדרות:
   - **Body/Skin:** בחר סקין **שונה לגמרי** מהבוט הלוחם — כדי שהשחקן יבדיל
   - **Behavior Type:** **Custom** (לא Guard! המאמן לא אמור לירות!)
   - **Equipment:** **ריק** — אל תתן לו נשק
   - **Behavior Script:** השאר ריק (המאמן לא צריך סקריפט התנהגות מותאם כרגע)
6. **שמור**

## 1.2 — NPC Spawner למאמן
1. ב-Content Browser חפש: `NPC Spawner`
2. **גרור NPC Spawner שני** (חדש!) לתוך ה-Viewport
   - **⚠️ זה spawner נפרד מזה של הבוט הלוחם!**
3. מקם אותו **בקצה הארנה** — לא באמצע, כדי שלא יפריע ללחימה
4. ב-Details Panel:

| הגדרה | ערך |
|---|---|
| **NPC Character Definition** | `BP_CoachNPC` |
| **Spawn on Game Start** | **כן (Enabled)** — המאמן תמיד נוכח |
| **Auto Respawn** | **כן** |
| **Max Spawn Count** | **1** |

5. **שמור**

## 1.3 — Persona Device (ה-AI שמדבר)
1. ב-Content Browser חפש: `Persona`
2. **אם מופיע "Persona Device":**
   - גרור לתוך ה-Viewport, ליד ה-NPC Spawner של המאמן
   - ב-Details Panel:
     - **Character/NPC:** קשר ל-NPC Spawner של המאמן
     - **Personality Description:** כתוב (באנגלית):
       ```
       You are a competitive Fortnite coach. Be direct, specific, and metric-driven.
       Reference ELO rating, DPS, headshot accuracy, and edit speed.
       Never give generic praise. Always suggest one specific improvement.
       Use Fortnite competitive terminology: piece control, edit peeks,
       trade damage, retakes, box fights.
       ```
     - **Voice:** בחר קול שנשמע מקצועי ורציני
   - **שמור**
3. **אם Persona Device לא קיים** בגרסה שלך:
   - זה בסדר! ה-`coach_controller` בקוד עדיין מדפיס הודעות ל-Output Log ול-HUD
   - ההודעות מופיעות דרך `hud_binding` → `DisplayCoachMsg`

---

# 🟡 2. וריאנטים של הבוט (Boxer, Retaker)

אלה גרסאות שונות של הבוט עם סגנונות לחימה שונים. **לא חובה לגרסה הראשונה** — הבוט הבסיסי מספיק.

## 2.1 — BP_CombatBot_Boxer (מומחה Box Fight)
1. **לחץ ימני** על `BP_CombatBot_Base` ב-Content Browser
2. בחר **Duplicate** (שכפל)
3. שנה שם ל: `BP_CombatBot_Boxer`
4. פתח ושנה:
   - **Skin:** סקין אחר (כדי להבדיל)
   - הכל השאר זהה — ההבדל בהתנהגות יגיע מהקוד (difficulty_mapper ישלוט)

## 2.2 — BP_CombatBot_Retaker (מומחה Height Retake)
1. שכפל שוב את `BP_CombatBot_Base`
2. שם: `BP_CombatBot_Retaker`
3. סקין שונה

**⚠️ כרגע שני הווריאנטים משתמשים באותו `bot_behavior_base`. בעתיד אפשר ליצור behavior scripts ייחודיים לכל אחד.**

---

# 🔴 3. פרופס עריכה (Edit Variants)

## מה זה
כשהבוט "עורך" קיר, המערכת מחביאה את הקיר המלא ומראה קיר עם חלון. לשם כך צריך **עותקים נוספים** של פרופס בצורות שונות.

## 3.1 — קיר עם חלון (Window Edit)
1. ב-Content Browser חפש: `Window Wall` או `Edited Wall`
2. אם לא מוצא — חפש `Arch Wall` או כל קיר עם פתח באמצע
3. **אם בכלל אין קיר עם חלון בספרייה:**
   - לך ל-**Modeling Mode** (כפתור בשורת כלים עליונה, או תפריט **Mode**)
   - צור קובייה ומחק את הפנים האמצעיים כדי ליצור "חלון"
   - או: פשוט השתמש בקיר רגיל בינתיים — עריכות יהיו בלי שינוי ויזואלי אבל המערכת עדיין תעבוד
4. שם: `SM_Wall_Wood_WindowEdit`
5. הנח **ב-Z = -5000** (מתחת לאדמה כמו שאר ה-pool)

## 3.2 — קיר עם דלת (Door Edit)
1. חפש: `Door Wall` או `Doorway`
2. שם: `SM_Wall_Wood_DoorEdit`
3. הנח ב-Z = -5000

## 3.3 — חיווט ל-edit_state_manager
1. בחר את `edit_state_manager` ב-Viewport
2. ב-Details Panel → **WallClusters** array
3. הוסף entries שמצביעים על הפרופס של ה-edit variants

---

# 🟡 4. NavMesh Proxy Planes (משטחי ניווט בלתי נראים)

## מה זה ולמה
אם בעתיד תשתמש ב-**Scene Graph** לגיאומטריה מותאמת, הבוט לא יוכל ללכת עליה כי Scene Graph לא נרשם ב-NavMesh. הפתרון: משטחים בלתי נראים מתחת.

## מתי צריך
**כרגע — לא צריך!** הרצפה הרגילה שהנחת יוצרת NavMesh. זה רלוונטי רק אם:
- אתה בונה ארנה מותאמת עם Scene Graph entities
- יש לך פלטפורמות מורמות שהבוט צריך להגיע אליהן

## איך עושים (אם צריך בעתיד):
1. ב-Content Browser חפש: `Invisible Barrier` או `Collision Box`
2. גרור לסצנה
3. מקם **בדיוק** באותו מיקום של הגיאומטריה של Scene Graph
4. Scale כך שמכסה את כל השטח
5. Build → Build Navigation
6. ה-NavMesh ירוק יופיע מעל ה-proxy

---

# 🟡 5. UMG Widgets — ממשק משתמש מפורט

## מה זה UMG
**UMG = Unreal Motion Graphics** — המערכת ליצירת ממשק משתמש (כפתורים, טקסטים, תמונות על המסך).

## 5.1 — יצירת Widget Blueprint
1. ב-Content Browser → **לחץ ימני** על שטח ריק
2. בתפריט, חפש: **User Interface** → **Widget Blueprint**
3. בחלון שנפתח, בחר **User Widget**
4. תן שם (לפי הרשימה למטה)
5. **לחץ כפול** לפתיחה — ייפתח עורך ויזואלי

## 5.2 — עורך ה-Widget — מה רואים
- **משמאל:** Palette (לוח כלים) — רשימת כל סוגי הרכיבים (Text, Image, Button...)
- **באמצע:** Designer (מעצב) — המסך שלך, כאן מסדרים את הרכיבים
- **מימין:** Details — הגדרות של הרכיב הנבחר

## 5.3 — Widget #1: `WBP_HUD_LiveStats` (HUD חי)
**תפקיד:** תצוגה קטנה בפינת המסך עם ELO, ניצחונות, מספר סבב

1. צור Widget Blueprint בשם `WBP_HUD_LiveStats`
2. פתח את העורך
3. מתוך **Palette** (משמאל), גרור **Text** ל-Designer
4. ב-Details (ימין):
   - **Text:** כתוב `ELO: 1000`
   - **Font Size:** `18`
   - **Color:** לבן
5. גרור עוד **Text** — כתוב `Round: 1`
6. גרור עוד **Text** — כתוב `W: 0 | L: 0`
7. גרור עוד **Text** — כתוב `DPS: 0.0`
8. סדר את 4 הטקסטים בפינה שמאלית עליונה של המסך
9. **שמור** (Ctrl+S)

**חיבור לנתונים:** ב-39.40+ יש תמיכה ב-**Verse Fields** — אפשר לקשר כל Text ל-property של `hud_binding`:
- בחר Text → ב-Details חפש **Binding** → בחר את ה-Verse device (`hud_binding`) → בחר property (`DisplayELO`)
- אם אין אפשרות Binding — הנתונים עדיין נשמרים ב-`hud_binding` ואפשר לגשת אליהם דרך Verse בעתיד

## 5.4 — Widget #2: `WBP_PostRound_Scorecard` (כרטיס תוצאות)
**תפקיד:** מסך מלא בסוף כל סבב

1. צור Widget Blueprint: `WBP_PostRound_Scorecard`
2. רכיבים:
   - **Text** גדול באמצע: "VICTORY" / "DEFEAT" / "DRAW" (Font Size: 48)
   - **Text** מתחת: ELO עם שינוי ("+32" או "-18")
   - **Text:** DPS
   - **Text:** Headshot %
   - **Text** למטה: הודעת מאמן
   - **Image/Panel** כרקע חצי-שקוף (צבע שחור, Opacity 0.7)
3. **שמור**

## 5.5 — Widget #3: `WBP_CoachDialogue` (בועת מאמן)
**תפקיד:** בועת טקסט שמופיעה כשהמאמן מדבר

1. צור Widget Blueprint: `WBP_CoachDialogue`
2. רכיבים:
   - **Image** כרקע בועה (מלבן מעוגל, צבע כהה, Opacity 0.8)
   - **Text** מעל: הודעת המאמן (Font Size: 16, צבע לבן)
3. מקם בתחתית המסך, מרכז

## 5.6 — Widget #4: `WBP_ELO_ProgressPanel` (גרף ELO)
**תפקיד:** פאנל צדדי שמציג את מסלול ה-ELO של השחקן

1. צור Widget Blueprint: `WBP_ELO_ProgressPanel`
2. רכיבים:
   - **Text:** "ELO Progress" (כותרת)
   - **Text:** ELO נוכחי
   - **Text:** Peak ELO
   - **Text:** Total Wins / Losses
   - **Progress Bar** (אם רוצים ייצוג ויזואלי)
3. מקם בצד ימין של המסך

## 5.7 — Widget #5: `WBP_Shop_MainMenu` (חנות)
**תפקיד:** ממשק החנות לקניית פריטים

1. צור Widget Blueprint: `WBP_Shop_MainMenu`
2. רכיבים:
   - **Text:** "SHOP" (כותרת, Font Size: 36)
   - **Button** #1 + Text: "Analytics Pass — 800 V-Bucks"
   - **Button** #2 + Text: "Cyber Arena — 300 V-Bucks"
   - **Button** #3 + Text: "Neon Arena — 300 V-Bucks"
   - **Button** #4 + Text: "5 Challenge Tokens — 250 V-Bucks"
   - **Button** "Close" בפינה
   - **Text** תחתון: יתרת Tokens

### איך מוסיפים Button:
1. מ-Palette גרור **Button** ל-Designer
2. גרור **Text** לתוך ה-Button (ה-Text הופך ל-child)
3. כתוב את הטקסט הרצוי

3. **שמור** כל widget

---

# 🟢 6. אנימציות מותאמות (אופציונלי)

## למה אופציונלי
הקוד כתוב עם **fallback** — אם אין אנימציות מותאמות, הוא משתמש בהשהייה סינתטית (Sleep). הבוט עדיין "בונה" (הפרופ מופיע) אבל בלי תנועת גוף מתאימה.

## אם רוצים להוסיף (בעתיד):
7 אנימציות מוגדרות ב-spec.md:
1. `Anim_Build_Wall` — תנועת הנחת קיר
2. `Anim_Build_Ramp` — תנועת הנחת רמפה
3. `Anim_Build_Floor` — תנועת הנחת רצפה
4. `Anim_Edit_Select` — פתיחת רשת עריכה
5. `Anim_Edit_Confirm` — אישור עריכה
6. `Anim_Pickaxe_Swing` — הנפת כלי הריסה
7. `Anim_Weapon_Swap` — החלפת נשק

### איך מייבאים:
1. צור/הורד אנימציות בפורמט `.fbx`
2. ב-UEFN: **File → Import** → בחר את ה-`.fbx`
3. שמור ב-Content folder
4. ודא שמופיעים ב-`Assets.digest.verse` (File → Save All → Build Verse)
5. עדכן את `build_animation_sync.verse` לקרוא לאנימציות במקום Sleep

---

# 🟢 7. Materials (חומרים — אופציונלי)

3 חומרים מוגדרים ב-spec.md:
1. **M_Arena_Default** — חומר בסיסי לארנה (אפור/לבן)
2. **M_HologramGrid** — אפקט הולוגרפי לתצוגת עריכה
3. **M_DamageFlash** — אפקט אדום כשנפגעים

**לא חובה לגרסה הראשונה.** הארנה עובדת עם חומרי ברירת מחדל.

### אם רוצים ליצור:
1. Content Browser → **לחץ ימני** → **Material**
2. שם: `M_Arena_Default`
3. פתח את עורך ה-Material ושנה צבע/texture
4. **Apply** על הרצפה: גרור את ה-Material מ-Content Browser ישירות על הרצפה ב-Viewport

---

# 📋 צ'קליסט סופי מורחב (כל הפרויקט)

## ליבה (חובה — בלי זה שום דבר לא עובד):
```
[ ] פרויקט UEFN נוצר
[ ] uplugin: EnableVerseAssetReflection = true
[ ] 35 קבצי Verse הועתקו
[ ] Build Verse succeeded
[ ] רצפת ארנה + NavMesh ירוק
[ ] BP_CombatBot_Base (Guard + Weapon + bot_behavior_base)
[ ] NPC Spawner מוגדר
[ ] Player Spawner מונח ומכוון
[ ] Item Granter (נשק לשחקן)
[ ] Island Settings: DBNO=Off
[ ] 16 Verse Devices בסצנה
[ ] 10 חיווטי @editable (game_manager, arena_controller, וכו')
[ ] 26 Pool Props ב-Z=-5000
[ ] build_pool_manager: 4 מערכים מלאים
[ ] Launch Session: בוט רודף + יורה + סבבים רצים
```

## שכבה שנייה (מומלץ — משפר משמעותית):
```
[ ] BP_CoachNPC נוצר + NPC Spawner למאמן
[ ] Persona Device מוגדר (אם זמין)
[ ] Edit variant props (Window + Door walls)
[ ] edit_state_manager מחווט
[ ] 5 UMG Widgets נוצרו
[ ] קירות גבול סביב הארנה
```

## שכבה שלישית (פוליש — לפני פרסום):
```
[ ] BP_CombatBot_Boxer + BP_CombatBot_Retaker (וריאנטים)
[ ] 7 אנימציות מותאמות מיובאות
[ ] 3 Materials מותאמים
[ ] NavProxy Planes (אם יש Scene Graph)
[ ] Arena cosmetic variants (Cyber + Neon)
[ ] cosmetic_applicator מחווט
[ ] כוונון טיימרים סופי (60s round)
[ ] בדיקת 100 סבבים רצופים
```
