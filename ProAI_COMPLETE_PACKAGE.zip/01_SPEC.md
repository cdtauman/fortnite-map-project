# spec.md — Architectural Blueprint & Software Specification
## Pro-Level AI Competitive Practice Map (Fortnite UEFN / Verse 2026)

> **Document Version:** 1.0  
> **Classification:** Source of Truth — Development Phase  
> **Architecture Tier:** Macro-Level Systems Design  
> **Engine Target:** Unreal Editor for Fortnite (UEFN) — 2026 Stable Branch  
> **Language:** Verse (Epic Games, 2026 API Surface)  
> **Code Policy:** ⛔ ZERO CODE IN THIS DOCUMENT — Architecture & Logic Flows Only

---

## Table of Contents

1. [Executive Summary & Design Philosophy](#1-executive-summary--design-philosophy)
2. [Global Constraints & Engine Limitations](#2-global-constraints--engine-limitations)
3. [Module A — Bot Behavior & Tactical Navigation](#3-module-a--bot-behavior--tactical-navigation)
4. [Module B — Build & Edit Simulation (The Illusion)](#4-module-b--build--edit-simulation-the-illusion)
5. [Module C — Dynamic Analytics & ELO System](#5-module-c--dynamic-analytics--elo-system)
6. [Module D — Persistence & Memory Management](#6-module-d--persistence--memory-management)
7. [Module E — Conversational AI (Virtual Coach)](#7-module-e--conversational-ai-virtual-coach)
8. [Module F — In-Island Economy & Monetization](#8-module-f--in-island-economy--monetization)
9. [UEFN Project Folder Structure](#9-uefn-project-folder-structure)
10. [File Roles & Component Definitions](#10-file-roles--component-definitions)
11. [Inter-Module Communication Map](#11-inter-module-communication-map)
12. [Phased Implementation Roadmap](#12-phased-implementation-roadmap)
13. [Risk Registry & Mitigation Matrix](#13-risk-registry--mitigation-matrix)
14. [Appendix — Glossary of Terms](#14-appendix--glossary-of-terms)

---

## 1. Executive Summary & Design Philosophy

### 1.1 Product Vision

This project delivers a **24/7 available, AI-driven competitive training environment** inside Fortnite Creative (UEFN). The map replaces the fragmented training ecosystem — where players currently rotate between static aim trainers, dead-room edit courses, and unpredictable human 1v1 lobbies — with a single unified experience featuring intelligent bot opponents that simultaneously function as **active combatants** and **analytical coaching entities**.

### 1.2 Core Design Pillars

**Pillar 1 — Dual-Role AI Identity.** Every bot on the map operates in two simultaneous capacities: as a realistic pro-level adversary (building, editing, shooting, taking trades) and as a silent analytical observer that surfaces pedagogical feedback. These roles are not toggled; they coexist continuously.

**Pillar 2 — The Illusion of Native Building.** Since UEFN NPCs have no access to the native Fortnite build API, all building and editing behavior must be achieved through a carefully orchestrated system of animations, prop spawning, prop manipulation, and object pooling. The player must perceive zero difference between the bot's "builds" and a human player's builds.

**Pillar 3 — Adaptive Difficulty as a Service.** The map implements a self-contained ELO rating system that adjusts bot reaction times, aim precision, build speed, and tactical aggression in real time. The player should always operate within the psychological "flow state" — challenged but not overwhelmed.

**Pillar 4 — Persistent Growth Tracking.** Every session contributes to a long-term player profile stored via Verse Persistence across four dedicated weak_map allocations. Players return to see their trajectory, not a blank slate.

**Pillar 5 — Economically Self-Sustaining.** The project leverages both Engagement Payouts (retention-weighted revenue) and the 2026 In-Island Transactions system to generate dual revenue streams from a high-value competitive audience.

### 1.3 Target User Persona

The primary audience comprises Ranked and FNCS competitive players who maintain daily warm-up routines, invest in mechanical improvement, and represent the highest-retention, highest-spending demographic in the Fortnite Creative ecosystem. Secondary audience includes aspiring competitive players seeking structured skill development.

---

## 2. Global Constraints & Engine Limitations

These constraints apply across ALL modules and must be respected as immutable laws of the architecture.

### 2.1 Hard Engine Constraints (Non-Negotiable)

| Constraint ID | Description | Impact | Source |
|---|---|---|---|
| **HC-01** | NPCs cannot access the native Fortnite build/edit API | All building must be simulated via props and animations | Engine Architecture |
| **HC-02** | Dynamic prop spawning has an approximate ceiling of ~100 active spawned objects before the engine halts creation to prevent server memory leaks | Build simulation must use Object Pooling, not infinite spawning | UEFN Runtime Limit |
| **HC-03** | Scene Graph entities are invisible to NavMesh calculation | Bot navigation zones must use traditional geometric props as NavMesh proxy layers | 2026 NavMesh Bug |
| **HC-04** | No HTTP/Web API calls are permitted from UEFN islands | All analytics, ranking, and player data must be self-contained using Verse Persistence only — zero external database dependency | Epic Security Policy |
| **HC-05** | Maximum of 4 `persistent weak_map` objects per island | Data partitioning strategy must fit within exactly 4 persistence slots | 2025 Expansion (from 2) |
| **HC-06** | Legacy persistent structs cannot have fields added or removed after deployment | Version migration must use the Optional Fields pattern (`?`) with migration functions | Verse Serialization |
| **HC-07** | Island Memory Limits apply to runtime object count and asset references | All visual assets must be budgeted; pooled objects count against memory even when hidden | UEFN Memory Budget |

### 2.2 Soft Constraints (Design Decisions)

| Constraint ID | Description | Rationale |
|---|---|---|
| **SC-01** | Bot focus target should offset to head height, not center-of-mass | Simulates pro-level headshot tracking; requires private Z-offset variable (~55.0 units) |
| **SC-02** | All concurrent bot actions (move + aim + animate) must use Verse `race` or `branch` expressions | Prevents "freezing" where a bot waits for navigation to complete before aiming |
| **SC-03** | Animation blending times (BlendInTime, BlendOutTime) must be non-zero | Prevents robotic, jerky transitions that break immersion |
| **SC-04** | XP distribution must stay within 30,000–200,000 points per 5–10 minute training block | Aligns with Chapter 7 Season 1 weekly XP cap economics without appearing exploitative |

---

## 3. Module A — Bot Behavior & Tactical Navigation

### 3.1 Responsibility

This module owns the complete lifecycle of every AI bot entity on the map, from spawn initialization through real-time combat decision-making, movement, aiming, and weapon discharge. It is the foundational layer upon which all other modules depend.

### 3.2 Class Hierarchy

The module's root is a **custom Verse class** inheriting from the engine-provided `npc_behavior` base class. This class is attached to an `npc_spawner_device` placed in the UEFN editor, or alternatively registered as a Behavior Script Override within the NPC Character Definition asset.

**Initialization Flow:**
1. The `OnBegin()` override fires when the bot entity is spawned into the virtual space.
2. Immediately extract the **Agent** reference via `GetAgent()`.
3. From the Agent, extract the **FortCharacter** via `GetFortCharacter()` — this is the master object granting access to Navigation, Focus, and Animation subsystems.
4. Cache references to: Navigation Interface, Focus Interface, Animation Controller. These are held as private class members for the bot's entire lifecycle.

### 3.3 Navigation Subsystem

**Interface Source:** `GetNavigatable` from the FortCharacter object.

**Target Resolution:** All navigation targets are constructed via `MakeNavigationTarget()`, which converts raw Vector3 coordinates (typically the human player's live position) or predefined strategic waypoints into engine-compatible navigation goals.

**Movement Execution:** The `NavigateTo()` function drives the bot toward its target. Critical parameters include:
- **MovementType** — Set to `movement_types.Running` for aggressive competitive rushing. Walking may be used for tactical repositioning.
- **ReachRadius** — Set to approximately 150.0 units to prevent unnatural "snapping" to the player's exact position. This creates a natural engagement distance buffer.

**NavMesh Constraint Workaround (HC-03):** Because Scene Graph objects do not register on the NavMesh, all arena surfaces where bots must navigate are constructed using **traditional geometry props** with physics collision enabled. An invisible NavMesh proxy layer of simple box/plane primitives is placed beneath or coincident with the visible arena geometry to ensure the AI pathfinding system recognizes walkable surfaces.

### 3.4 Concurrency Model

Competitive combat requires a bot to simultaneously move, aim, and execute actions. Verse's structured concurrency primitives are essential:

- **`race` blocks** — Used when two or more actions compete for resolution. Example: the bot navigates toward the player while also listening for an "enemy edit detected" event. Whichever completes first dictates the next behavioral branch (continue rushing vs. take cover).
- **`branch` expressions** — Used to fork non-blocking background tasks. Example: spawn a background task that continuously updates the Focus target while the main thread handles navigation and weapon logic.
- **`sync` blocks** — Used when multiple conditions must ALL complete before proceeding. Example: ensure both the "build animation complete" AND "prop spawn confirmed" events resolve before transitioning to the "shoot through edit" state.

### 3.5 Focus & Aiming System

**Interface Source:** `GetFocusInterface()` from the FortCharacter.

**Base Behavior:** The `MaintainFocus(Agent)` command locks the bot's upper body orientation and weapon aim toward the target player, independent of the bot's movement vector. This enables realistic strafe-and-shoot mechanics where the bot moves laterally while firing toward the player.

**Headshot Offset (SC-01):** The default Focus target aims at center-of-mass (waist/torso). A private float variable (`VerticalOffsetToNPCHead ≈ 55.0`) is added to the Z-axis of the focus target position. This displaces aim upward from waist to head/neck region, simulating elite shotgun and rifle tracking behavior.

**Dynamic Offset Adjustment:** The Z-offset value is not static. Module C (Analytics/ELO) feeds difficulty parameters back to Module A, which scales the offset precision:
- Low ELO difficulty → Offset varies randomly by ±15 units (simulates inconsistent aim)
- High ELO difficulty → Offset is locked precisely at head height with near-zero variance

### 3.6 Weapon & Engagement Logic

Weapon selection and firing patterns are managed by a **state machine** within the behavior class. States include:
- **APPROACH** — Bot navigates toward the player, Focus active, weapon holstered or passively held.
- **ENGAGE_CLOSE** — Within shotgun range (~3 tiles). Switch to shotgun, fire on edit-peek windows, prioritize headshots.
- **ENGAGE_MID** — Assault rifle range. Controlled burst fire with tracking, slight aim sway at lower ELO.
- **DISENGAGE** — Health threshold reached. Bot retreats, places defensive builds (via Module B), heals if economy allows.
- **BUILD_AGGRO** — Bot executes offensive building sequences (via Module B) to take high ground or box the player.

State transitions are driven by distance calculations, health thresholds, and signals from Module C's predictive engine.

### 3.7 Anti-Clipping Safeguards

When bots execute rapid teleportation-based repositioning (used during build simulation or forced retreat), minor Z-axis corrections are applied via `MoveToTile` functions to prevent the bot model from clipping through floor geometry. This is especially critical during vertical build sequences where the bot "ascends" spawned ramp/floor props.

---

## 4. Module B — Build & Edit Simulation (The Illusion)

### 4.1 Responsibility

This module creates a **perceptually indistinguishable simulation** of Fortnite's native building and editing system, using only tools available to UEFN NPC scripting. The player must believe the bot is building walls, placing ramps, editing windows, and performing piece control — none of which is natively possible for scripted NPCs (HC-01).

### 4.2 The Three-Layer Illusion

The simulation operates as three synchronized layers that fire in precise temporal coordination:

**Layer 1 — Animation (Visual Body Movement)**
The bot plays custom animations that mimic the physical gestures of building: pulling out a blueprint, swinging a pickaxe to break a wall, holding an edit grid. These are played via the `PlayAnimationController` accessed through `GetPlayAnimationController()` on the FortCharacter.

**Layer 2 — Prop Materialization (Physical World Objects)**
At the exact animation keyframe where a human player's build would "place," a pre-modeled wall/ramp/floor prop is spawned or teleported into position in front of the bot, aligned with its facing vector and grid position.

**Layer 3 — Prop Manipulation (Edit State Changes)**
To simulate edits (window, door, half-wall, stair rotation), the system does not destroy and recreate props. Instead, it swaps the visual state of existing props using `prop_manipulator_device` — hiding one variant and revealing another that represents the edited state.

### 4.3 Asset Reflection Pipeline

For Verse scripts to reference custom animation files and prop models, the **Asset Reflection** system must be enabled at the project level:

1. The project's `.uplugin` configuration file must contain the flag `"EnableVerseAssetReflection": true`.
2. All asset modules containing models, textures, and animations (e.g., `Assets.digest.verse`) must be marked with `<public>` visibility so the Verse runtime can resolve file paths.
3. After enabling, the project must be rescanned to rebuild the asset registry.

**Critical Path:** If this step is missed, no custom animation or prop model can be referenced from Verse code, and the entire build simulation system fails silently.

### 4.4 Animation Execution Detail

Once the Animation Controller is obtained:
- Animations are triggered via `Play()` (fire-and-forget) or `PlayAndAwait()` (blocking until complete).
- **PlayRate** is scaled dynamically by the ELO system (Module C). Higher difficulty = faster build animations.
- **BlendInTime** and **BlendOutTime** are always set to non-zero values (SC-03) to ensure smooth transitions between combat and build states. Typical values: 0.15s blend-in, 0.1s blend-out.
- The animation system exposes events: `BlendedInEvent` (animation has fully blended into active state) and `CompletedEvent` (animation has finished playing). These are the synchronization anchors for Layer 2.

### 4.5 Prop Spawning & Positioning

**Primary Method — `SpawnProp()`:**
- Accepts: a Prop asset reference (e.g., classic Fortnite wood wall model), a `SpawnPosition:vector3` computed from the bot's position and look vector, and rotation (typically `IdentityRotation()` or calculated to face the player).
- The spawn is triggered on the `BlendedInEvent` of the build animation, creating a tight visual sync.

**Spawn Position Calculation:**
The target position is computed mathematically: take the bot's current world position, project forward along its facing vector by one grid tile (approximately 256 Unreal units), and snap to the nearest grid-aligned coordinate. Vertical offset (Z) accounts for whether the piece is a floor, wall, or ramp.

### 4.6 Object Pooling Architecture (Critical — HC-02)

**Problem:** Unconstrained use of `SpawnProp()` will trigger the engine's ~100 object safety limit, causing all subsequent spawn calls to fail silently and potentially crashing the server via memory leaks.

**Solution — Recycled Memory Cluster Pattern:**

The system pre-allocates a **fixed pool** of prop objects at map initialization. These objects are created once during the `OnBegin` phase and never destroyed during gameplay.

**Pool Lifecycle:**
1. **INIT** — At map start, spawn the maximum required number of each prop type (walls, ramps, floors, cones) and immediately teleport them to a hidden underground staging area (e.g., Z = -5000).
2. **DEPLOY** — When the bot needs to "place" a build piece, the system claims an available object from the pool, teleports it (`TeleportTo` or `MoveTo`) to the calculated build position, and marks it as "active."
3. **RECLAIM** — When a build piece is no longer needed (fight ended, piece "destroyed" by the player, or arena reset), the object is teleported back underground and marked as "available."
4. **OVERFLOW GUARD** — If all pool objects of a given type are active, the system reclaims the oldest deployed object (FIFO) before deploying a new one. This prevents pool exhaustion during extended fights.

**Pool Sizing:** Based on typical competitive box fight scenarios, the recommended pool per bot instance is: 12 walls, 6 floors, 4 ramps, 4 cones = 26 objects per bot. With 2 concurrent bots maximum, total pool = 52 props, safely under the ~100 limit with headroom for UI props and arena objects.

### 4.7 Edit Simulation via Prop Manipulation

**Device:** `prop_manipulator_device`

**Mechanism:** Each "wall" in the pool is not a single prop but a **cluster of 2–3 overlapping prop variants** at the same grid position:
- Variant A: Full wall (default visible state)
- Variant B: Wall with center window edit (hidden by default)
- Variant C: Wall with right-side door edit (hidden by default)

When the bot performs an "edit," the system:
1. Triggers the edit animation (pickaxe swing or grid-select gesture).
2. On `CompletedEvent`, uses `prop_manipulator_device` to hide Variant A and reveal Variant B.
3. The visual result: the player sees a wall "edited" into a window in real time.

**Reversal:** To "reset" the edit, reverse the visibility toggle.

### 4.8 Physics Integration (2025+ UEFN Capabilities)

Props designated for the build simulation can be flagged as destructible physics bodies within the UEFN editor's properties panel. This means:
- Players can shoot and destroy the bot's "builds" just as they would destroy real player builds.
- Destroyed props trigger the reclaim cycle, returning them to the underground pool for re-use.
- Damage events on props can be listened to by Module C for analytics (tracking the player's ability to break into boxes).

---

## 5. Module C — Dynamic Analytics & ELO System

### 5.1 Responsibility

This module operates as the map's **central nervous system for intelligence**. It continuously ingests gameplay events, computes real-time performance metrics, feeds difficulty adjustments back to Module A/B, generates predictive warnings, and writes analytical snapshots to Module D for persistence.

### 5.2 Real-Time Data Ingestion

The analytics engine runs as a **persistent background process** (via Verse `branch` expression) that subscribes to events from Modules A and B. Tracked data points per frame/tick window:

| Metric | Source Module | Measurement | Unit |
|---|---|---|---|
| Edit Speed | B (Animation Events) | Time between edit-start animation trigger and edit-complete visibility swap | Edits per second (EPS) |
| Wall Placement Accuracy | B (Spawn Position vs. Ideal Grid) | Deviation between placed prop position and optimal grid-snap | Distance in Unreal units |
| Damage Per Second (DPS) Velocity | A (Weapon Hit Events) | Damage dealt to bot divided by engagement time window | HP/second |
| Reaction Time | A (Player Movement Events) | Elapsed time between bot action (peek, edit, push) and player's responsive action | Milliseconds |
| Headshot Ratio | A (Hit Zone Detection) | Percentage of player hits landing on bot's head hitbox vs. body | Percentage |
| Opportunity Cost (Peeking) | A + B (Positional Analysis) | Time spent exposed during peek-and-shoot sequences vs. time in cover | Ratio |
| Box Closure Efficiency | B (Prop State Tracking) | Time to complete a full 1x1 box enclosure around the bot or in defensive scenarios | Seconds |

### 5.3 Profiling & Predictive Engine

The analytics engine maintains a **rolling window** of the last N engagements (recommended: N = 10) and computes trend vectors for each metric. This enables the "Smart Advisor" functionality:

**Failure Prediction:** If the trend vector for edit speed is declining while the bot's ELO difficulty is static or rising, the engine predicts an imminent loss. It can issue a pre-emptive coaching alert approximately 15 seconds before a statistically likely box fight loss.

**Pattern Detection:** The engine identifies recurring tactical errors. Example: "Player consistently leaves left-side wall exposed after right-side edit peek." This pattern data is forwarded to Module E (Conversational Coach) for verbal feedback delivery.

**Metric Aggregation for ELO:** After each combat round, the engine compiles a composite performance score from weighted metrics and feeds it to the ELO calculation subroutine.

### 5.4 ELO Rating System

**Mathematical Foundation:**

The ELO system uses the standard expected probability formula:

```
E(player) = 1 / (1 + 10^((R_bot - R_player) / 400))
```

Where:
- `R_player` = Player's current ELO rating (persisted via Module D)
- `R_bot` = Bot's current difficulty rating
- `E(player)` = Expected probability of the player winning the round

**Rating Update After Each Round:**

```
R_player_new = R_player + K × (S - E(player))
```

Where:
- `K` = K-factor constant (recommended: K = 32 for standard, K = 48 for placement matches during first 10 rounds)
- `S` = Actual outcome (1.0 for win, 0.0 for loss, 0.5 for draw/timeout)

**Difficulty Mapping:**

The bot's ELO rating is not just a number — it maps directly to behavioral parameters in Module A and speed parameters in Module B:

| ELO Bracket | Bot Reaction Window | Aim Z-Offset Variance | Build Animation PlayRate | Tactical Complexity |
|---|---|---|---|---|
| 0–800 (Beginner) | 600–800ms | ±20 units (chest hits common) | 0.6x (slow builds) | Simple rushes, no edits |
| 800–1200 (Intermediate) | 350–500ms | ±10 units (mixed head/body) | 0.85x (moderate speed) | Basic edits, simple piece control |
| 1200–1600 (Advanced) | 200–350ms | ±5 units (mostly headshots) | 1.0x (human-speed builds) | Complex edits, retakes, trades |
| 1600–2000 (Pro) | 100–200ms | ±2 units (sniper-level precision) | 1.2x (faster-than-average) | Full piece control, prediction plays |
| 2000+ (Elite) | 50–100ms | ±0 units (perfect tracking) | 1.4x (pro tournament speed) | Adaptive counter-strategies |

### 5.5 Anti-Stagnation Mechanisms

If the player's ELO has not changed by more than ±25 points over 5 consecutive rounds, the system introduces **volatility injection**: temporarily increase K-factor to 64 for 3 rounds, and introduce a novel bot behavior pattern the player has not encountered (e.g., switch from aggressive box-fight style to height-retake style). This prevents plateau frustration.

---

## 6. Module D — Persistence & Memory Management

### 6.1 Responsibility

This module manages all long-term data storage using Verse's built-in Persistence system, operating within the hard constraint of exactly 4 `persistent weak_map` allocations (HC-05). It handles data partitioning, version migration, and serialization budgets.

### 6.2 Data Partitioning Across 4 Weak Maps

| Weak Map Slot | Designation | Stored Data | Write Frequency |
|---|---|---|---|
| **Slot 1** | Raw Analytics Store | Per-session metric snapshots: EPS averages, DPS velocity, reaction times, headshot ratios. Last 50 sessions stored in rolling buffer. | End of each training round |
| **Slot 2** | Social & Rating Profile | Player ELO rating, win/loss record vs. each bot difficulty tier, rank badge level, total training hours, creation timestamp. | End of each training session |
| **Slot 3** | Progression & Quest Journal | Current active tactical challenges (e.g., "Win 3 box fights at ELO 1200+"), completion status, historical milestone log, unlocked coaching modules. | On quest completion events |
| **Slot 4** | Economy & Inventory Ledger | Purchased cosmetic arena skins, active subscription pass status, consumable item balances, transaction history log. | On purchase events |

### 6.3 Version Migration Pattern (HC-06)

All persistent data classes use the **Optional Fields** paradigm to enable safe schema evolution without corrupting existing player profiles.

**Structural Pattern:**

The root data class contains optional references (`?`) to versioned sub-classes. Each version sub-class is marked `<persistable><final>`.

**Migration Process:**
1. When a new version (e.g., V3) is needed, add a new optional field `V3:?player_data_v3 = false` to the root class.
2. On player load, check if V3 exists. If not, run a migration function that reads V2 data, transforms it to V3 format, writes V3, and sets V1/V2 to `false` (disabled).
3. Disabled version fields no longer consume serialization budget on subsequent loads.

**Version Changelog Protocol:** Every schema change must be documented in a dedicated migration log within the project, specifying: the old field layout, the new field layout, the transformation logic, and the UEFN version in which the change was deployed.

### 6.4 Serialization Budget Management

Each weak_map has a per-player serialization size limit. To stay within budget:
- Use integer representations where possible (store ELO as int, not float).
- Store metric snapshots as fixed-size arrays with oldest-entry overwrite (ring buffer), not unbounded lists.
- Compress quest states into bitfield integers (each bit = one quest completion flag).
- Avoid storing string data in persistence; use integer enum codes that map to display strings at runtime.

### 6.5 Data Integrity Safeguards

- All write operations are wrapped in validation checks that verify the data passes internal consistency rules before committing to the weak_map.
- A "last known good" timestamp field is maintained; if data load fails or produces impossible values (e.g., negative ELO), the system restores defaults and flags the profile for manual review via Module E coaching message.

---

## 7. Module E — Conversational AI (Virtual Coach)

### 7.1 Responsibility

This module transforms the bot from a silent adversary into an **active pedagogical agent** that delivers contextual, analytics-informed verbal coaching during and after combat encounters. It leverages the 2025-introduced **Persona Device** system.

### 7.2 Persona Device Integration

The Persona Device, announced at State of Unreal 2025, enables UEFN creators to imbue NPCs with deep personality traits and autonomous conversational dialogue capabilities. It was prototyped publicly in the Galactic Battle season via the Darth Vader NPC, which responded to players contextually and autonomously.

**Configuration:** The Persona Device is attached to a dedicated "Coach" NPC entity (separate from the combat bots, or optionally merged as a post-fight mode on the combat bot). The device is configured with:
- **Personality Profile:** Firm but encouraging competitive coach persona. Tone: direct, specific, action-oriented. No generic praise — all feedback references concrete metrics.
- **Knowledge Base:** Fed with Fortnite competitive terminology, mechanical concepts (piece control, edit peeks, trade damage, retakes), and the player's current analytical profile from Module C.

### 7.3 Feedback Trigger Architecture

The Coach does not speak continuously. It activates on **trigger events** determined by Module C:

| Trigger Condition | Coach Response Type | Example |
|---|---|---|
| Round ended (win or loss) | Performance summary with 1 specific improvement suggestion | "You won that fight, but your edit speed dropped 15% in the last exchange. Focus on pre-aiming before opening the edit." |
| Pattern weakness detected (3+ occurrences) | Targeted drill suggestion | "You've left your left wall exposed after right-peek edits three times now. Try diagonal edits to maintain cover." |
| Frustration signal (5+ consecutive losses) | Motivational reset + difficulty adjustment offer | "Tough streak. I'm dialing the difficulty back slightly so you can rebuild rhythm. Ready when you are." |
| New ELO milestone reached | Achievement acknowledgment | "You just broke into the 1400 bracket. Bot reaction times are now under 300ms. Let's see what you've got." |
| Extended session (30+ minutes without break) | Wellness nudge | "You've been grinding for 35 minutes. A short break can actually improve reaction time. I'll be here when you get back." |

### 7.4 Event-to-Game-Logic Bridge

The Persona Device's documented capability extends beyond dialogue — it can trigger Verse-side game logic events based on conversational context. This enables the Coach to:
- Instruct the arena controller to spawn additional practice aids (e.g., extra materials) after detecting frustration.
- Modify gravity or movement speed parameters temporarily for drill-specific exercises.
- Change the combat bot's evasion patterns or build styles on-the-fly to target specific weaknesses.
- Unlock gated training modules (e.g., "You've shown consistent improvement in edits. I'm opening the Advanced Retake course.").

### 7.5 UMG Visual Feedback Layer

Alongside verbal coaching, Module E drives on-screen HUD elements via the **UMG (Unreal Motion Graphics)** system, which in 2025 gained direct data-binding support from Verse classes:
- **Live stat overlay:** EPS counter, headshot %, current ELO displayed in a minimal HUD widget.
- **Post-round scorecard:** Full-screen overlay showing the round's metrics vs. personal bests, with trend arrows (↑↓→).
- **Progress timeline:** A side-panel widget showing the player's ELO trajectory over the last 20 sessions as a mini-graph.

Data binding connects Verse analytics variables directly to UMG widget properties, eliminating the need for manual UI update calls and ensuring real-time visual accuracy.

---

## 8. Module F — In-Island Economy & Monetization

### 8.1 Responsibility

This module implements the complete in-map economy using the 2026 **In-Island Transactions** system, creating sustainable revenue through virtual goods that enhance the training experience without compromising competitive integrity (no pay-to-win).

### 8.2 Revenue Stream Architecture

**Stream 1 — Engagement Payouts (Passive):**
This is the automatic revenue generated by Epic's algorithm based on player time-on-island, return rates, and economic participation of visitors. The map is architecturally optimized for this by:
- Maximizing session duration through ELO-driven flow state maintenance.
- Encouraging daily return habits via persistent progression and daily challenges (Module D Slot 3).
- Attracting high-value players (V-Bucks purchasers) who inherently boost payout multipliers.

**Stream 2 — In-Island Transactions (Active):**
Launched January 9, 2026, this system allows direct V-Bucks sales within Creative islands. The 100% revenue retention window (through January 2027) represents a critical early-mover advantage. Post-window, the split normalizes to 50/50 with Epic.

### 8.3 Product Catalog Design

| Category | Product | Pricing Strategy | P2W Risk | Revenue Type |
|---|---|---|---|---|
| **Progression Pass** | "Advanced Analytics Pass" — unlocks deep AI metric dashboards, full combat history replay, and access to Elite (2000+) difficulty bots | Mid-tier (~800 V-Bucks). Anchoring: show a "Pro Bundle" at 1500 to make 800 feel reasonable | None — purely informational advantage | Recurring (seasonal) |
| **Cosmetic Arenas** | Themed arena skins: Cyberpunk Arena, Neon Grid, Classic Wood, Tournament Stage | Low-tier (200–500 V-Bucks each). Sold individually or in discounted bundle | Zero — purely aesthetic | One-time (durable) |
| **Consumable Tokens** | "Challenge Tokens" — grant entry to special high-difficulty scenario modes (e.g., 1v2 bot fights, survival rounds) | Micro-tier (50–100 V-Bucks per token, or packs of 5 at discount) | Minimal — scenarios are for practice, not rank | Recurring (consumable) |
| **Gameplay Modifiers** | Temporary fun modifiers: "Speed Boots" (faster movement in drill mode), "Slow-Mo Replay" (watch last fight in slow motion) | Low-tier (100–200 V-Bucks) | None — training aids, not competitive advantages | Recurring (consumable) |

### 8.4 Anti-Pay-to-Win Design Principles

- No purchasable item affects ELO calculations.
- No purchasable item increases damage, health, or any combat stat.
- All core training functionality (basic analytics, standard difficulty bots, ELO system) is free.
- Paid tiers offer depth of insight (richer data), variety (cosmetics, special scenarios), and convenience (not power).

### 8.5 Transaction UI Integration

Purchase flows are implemented via UEFN's In-Island Transaction API, triggered from UMG shop menu widgets. Module D (Slot 4) records all purchases and active subscriptions. The shop UI is accessed via an in-game terminal prop or menu button, keeping the purchase flow non-intrusive during training.

---

## 9. UEFN Project Folder Structure

```
📁 ProAI_TrainingMap/
│
├── 📄 ProAI_TrainingMap.uplugin            ← Project manifest (EnableVerseAssetReflection: true)
│
├── 📁 Content/
│   │
│   ├── 📁 Maps/
│   │   └── 📄 MainIsland.umap              ← Primary island level file
│   │
│   ├── 📁 Blueprints/
│   │   ├── 📁 NPCs/
│   │   │   ├── 📄 BP_CombatBot_Base.uasset  ← NPC Character Definition (combat bot)
│   │   │   ├── 📄 BP_CombatBot_Boxer.uasset  ← Variant: Box fight specialist
│   │   │   ├── 📄 BP_CombatBot_Retaker.uasset ← Variant: Height retake specialist
│   │   │   └── 📄 BP_CoachNPC.uasset         ← NPC Character Definition (virtual coach)
│   │   │
│   │   ├── 📁 Devices/
│   │   │   ├── 📄 BP_NPC_Spawner_Combat.uasset   ← Spawner device config for combat bots
│   │   │   ├── 📄 BP_NPC_Spawner_Coach.uasset     ← Spawner device config for coach NPC
│   │   │   ├── 📄 BP_PersonaDevice_Coach.uasset    ← Persona Device for coach AI personality
│   │   │   ├── 📄 BP_PropManipulator_Walls.uasset  ← Prop manipulator for wall edit states
│   │   │   ├── 📄 BP_PropManipulator_Floors.uasset ← Prop manipulator for floor edit states
│   │   │   └── 📄 BP_TriggerZones.uasset           ← Arena boundary and event triggers
│   │   │
│   │   └── 📁 UI/
│   │       ├── 📄 WBP_HUD_LiveStats.uasset     ← UMG widget: Live stat overlay
│   │       ├── 📄 WBP_PostRound_Scorecard.uasset ← UMG widget: End-of-round analytics
│   │       ├── 📄 WBP_ELO_ProgressPanel.uasset  ← UMG widget: ELO trajectory graph
│   │       ├── 📄 WBP_Shop_MainMenu.uasset       ← UMG widget: In-island shop interface
│   │       └── 📄 WBP_CoachDialogue.uasset        ← UMG widget: Coach speech bubbles
│   │
│   ├── 📁 Props/
│   │   ├── 📁 BuildPieces/
│   │   │   ├── 📄 SM_Wall_Wood_Full.uasset        ← Wall model: full state
│   │   │   ├── 📄 SM_Wall_Wood_WindowEdit.uasset   ← Wall model: center window edit
│   │   │   ├── 📄 SM_Wall_Wood_DoorEdit.uasset     ← Wall model: right door edit
│   │   │   ├── 📄 SM_Floor_Wood_Full.uasset         ← Floor model: full state
│   │   │   ├── 📄 SM_Ramp_Wood_Full.uasset          ← Ramp model: standard orientation
│   │   │   └── 📄 SM_Cone_Wood_Full.uasset          ← Cone/pyramid model
│   │   │
│   │   ├── 📁 ArenaElements/
│   │   │   ├── 📄 SM_Arena_Default.uasset           ← Standard grey training arena
│   │   │   ├── 📄 SM_Arena_Cyberpunk.uasset         ← Purchasable cosmetic arena
│   │   │   └── 📄 SM_Arena_Neon.uasset              ← Purchasable cosmetic arena
│   │   │
│   │   └── 📁 NavMeshProxy/
│   │       └── 📄 SM_NavProxy_Plane.uasset          ← Invisible NavMesh-compatible surfaces
│   │
│   ├── 📁 Animations/
│   │   ├── 📄 Anim_Build_Wall.uasset                ← Bot animation: placing a wall
│   │   ├── 📄 Anim_Build_Ramp.uasset                ← Bot animation: placing a ramp
│   │   ├── 📄 Anim_Build_Floor.uasset               ← Bot animation: placing a floor
│   │   ├── 📄 Anim_Edit_Select.uasset               ← Bot animation: opening edit grid
│   │   ├── 📄 Anim_Edit_Confirm.uasset              ← Bot animation: confirming edit
│   │   ├── 📄 Anim_Pickaxe_Swing.uasset             ← Bot animation: pickaxe break
│   │   └── 📄 Anim_Weapon_Swap.uasset               ← Bot animation: weapon switch gesture
│   │
│   └── 📁 Materials/
│       ├── 📄 M_Arena_Default.uasset                 ← Base arena material
│       ├── 📄 M_HologramGrid.uasset                  ← Holographic edit-preview effect
│       └── 📄 M_DamageFlash.uasset                   ← Hit feedback visual material
│
├── 📁 Verse/
│   │
│   ├── 📁 Core/
│   │   ├── 📄 game_manager.verse                ← Master orchestrator: round lifecycle, state machine
│   │   ├── 📄 arena_controller.verse             ← Arena reset, zone management, prop pool init
│   │   └── 📄 event_bus.verse                    ← Centralized event dispatch and subscription hub
│   │
│   ├── 📁 ModuleA_BotBehavior/
│   │   ├── 📄 bot_behavior_base.verse            ← Root npc_behavior class (OnBegin, agent caching)
│   │   ├── 📄 bot_navigation.verse               ← NavMesh movement, target resolution, reach radius
│   │   ├── 📄 bot_focus_aim.verse                ← Focus interface, Z-offset headshot logic
│   │   ├── 📄 bot_combat_state_machine.verse     ← State machine: APPROACH/ENGAGE/DISENGAGE/BUILD
│   │   ├── 📄 bot_weapon_controller.verse        ← Weapon selection, fire rate, burst patterns
│   │   └── 📄 bot_difficulty_profile.verse       ← Parameter struct receiving ELO-driven values
│   │
│   ├── 📁 ModuleB_BuildSimulation/
│   │   ├── 📄 build_pool_manager.verse           ← Object pool init, claim, reclaim, overflow guard
│   │   ├── 📄 build_animation_sync.verse         ← Animation playback, event listeners, blend config
│   │   ├── 📄 build_prop_spawner.verse           ← SpawnProp positioning math, grid alignment
│   │   ├── 📄 edit_state_manager.verse           ← Prop manipulator control, variant visibility toggling
│   │   └── 📄 build_sequence_choreographer.verse ← Orchestrates multi-step build sequences (ramp rush, box-up, retake)
│   │
│   ├── 📁 ModuleC_Analytics/
│   │   ├── 📄 analytics_engine.verse             ← Background data ingestion loop, metric computation
│   │   ├── 📄 metric_definitions.verse           ← Structs for all tracked metrics (EPS, DPS, etc.)
│   │   ├── 📄 elo_calculator.verse               ← ELO math: expected probability, rating update, K-factor
│   │   ├── 📄 difficulty_mapper.verse            ← Translates ELO bracket to bot behavior parameters
│   │   ├── 📄 predictive_advisor.verse           ← Trend analysis, failure prediction, anti-stagnation
│   │   └── 📄 session_aggregator.verse           ← Compiles round data into session summaries for persistence
│   │
│   ├── 📁 ModuleD_Persistence/
│   │   ├── 📄 persistence_manager.verse          ← Master persistence controller: load, save, migrate
│   │   ├── 📄 data_schema_v1.verse               ← V1 persistable class definitions
│   │   ├── 📄 data_schema_v2.verse               ← V2 persistable class definitions (current)
│   │   ├── 📄 migration_v1_to_v2.verse           ← Migration transformation function
│   │   └── 📄 data_validator.verse               ← Integrity checks, impossible-value detection, defaults
│   │
│   ├── 📁 ModuleE_Coach/
│   │   ├── 📄 coach_controller.verse             ← Trigger evaluation, feedback dispatch to Persona Device
│   │   ├── 📄 feedback_templates.verse           ← Parameterized coaching message templates
│   │   └── 📄 coach_game_bridge.verse            ← Event-to-game-logic actions (difficulty adjust, aid spawn)
│   │
│   ├── 📁 ModuleF_Economy/
│   │   ├── 📄 shop_manager.verse                 ← Product catalog, purchase flow, V-Bucks API hooks
│   │   ├── 📄 inventory_controller.verse         ← Owned items, consumable balances, subscription status
│   │   ├── 📄 xp_reward_system.verse             ← XP distribution logic (30K–200K per block)
│   │   └── 📄 cosmetic_applicator.verse          ← Arena skin swapping, visual modifier application
│   │
│   └── 📁 UI/
│       ├── 📄 hud_binding.verse                  ← Data-binding bridge: Verse analytics → UMG widgets
│       ├── 📄 scorecard_renderer.verse           ← Post-round scorecard data formatter
│       └── 📄 shop_ui_controller.verse           ← Shop menu interaction logic, purchase confirmation
│
└── 📁 Assets.digest.verse                        ← Asset registry module (<public> visibility)
```

---

## 10. File Roles & Component Definitions

### 10.1 Core Layer

| File | Role | Communicates With | Inputs | Outputs |
|---|---|---|---|---|
| `game_manager.verse` | Master orchestrator. Controls round lifecycle (lobby → countdown → fight → post-round → reset). Manages global game state transitions. | ALL modules | Player join events, round timer, kill/death events | Round-start/end signals to all modules |
| `arena_controller.verse` | Manages the physical arena space. Initializes the object pool (Module B), resets arena between rounds, manages zone boundaries. | Module B (pool init), Module F (cosmetic arena swaps) | Round-reset signal from game_manager | Pool-ready signal, arena-clean signal |
| `event_bus.verse` | Centralized pub/sub event system. All inter-module communication routes through here to decouple dependencies. | ALL modules | Event publications from any module | Event deliveries to subscribed modules |

### 10.2 Module A — Bot Behavior

| File | Role | Communicates With | Inputs | Outputs |
|---|---|---|---|---|
| `bot_behavior_base.verse` | Root NPC behavior class. Inherits `npc_behavior`. Handles OnBegin initialization and agent reference caching. | Navigation, Focus, Combat State Machine | Spawn event | Cached Agent, FortCharacter, interface references |
| `bot_navigation.verse` | All movement logic. Target resolution, NavigateTo calls, ReachRadius management, NavMesh proxy awareness. | bot_behavior_base (character refs), bot_combat_state_machine (movement orders) | Target position (player or waypoint), movement type | Movement-complete events, position updates |
| `bot_focus_aim.verse` | Focus interface management. MaintainFocus calls, Z-offset calculation, dynamic precision scaling from ELO. | bot_behavior_base (character refs), difficulty_profile (precision params) | Target player reference, Z-offset value, variance range | Continuous aim direction updates |
| `bot_combat_state_machine.verse` | Central decision engine. Evaluates distance, health, ammo, and analytics signals to transition between combat states. | Navigation, Focus, Weapon, Module B (build orders), Module C (difficulty signals) | Distance to player, health values, ELO bracket params | State transition commands to all sub-systems |
| `bot_weapon_controller.verse` | Weapon selection and firing logic. Burst patterns, fire rate, weapon swap timing. | bot_combat_state_machine (weapon orders), bot_focus_aim (aim direction) | Current state, weapon inventory, fire rate params | Damage events (published to event_bus for Module C) |
| `bot_difficulty_profile.verse` | Data struct holding all ELO-driven parameters for a single bot instance. Updated by Module C after each round. | Module C (difficulty_mapper writes values), all Module A files (read values) | ELO bracket determination from Module C | Reaction time, aim variance, build speed, aggression level |

### 10.3 Module B — Build Simulation

| File | Role | Communicates With | Inputs | Outputs |
|---|---|---|---|---|
| `build_pool_manager.verse` | Owns the object pool lifecycle. Pre-spawns all props at map init, manages claim/reclaim/overflow. | arena_controller (init trigger), build_prop_spawner (claim requests), edit_state_manager (reclaim signals) | Pool size config, arena-ready signal | Available prop references on claim, pool status metrics |
| `build_animation_sync.verse` | Controls animation playback on bot characters. Manages PlayRate (ELO-scaled), blend times, and event subscriptions. | bot_behavior_base (animation controller ref), build_prop_spawner (BlendedIn trigger) | Build command from state machine, PlayRate from difficulty_profile | BlendedInEvent, CompletedEvent signals |
| `build_prop_spawner.verse` | Computes spawn positions (grid math) and teleports claimed pool objects to target coordinates. | build_pool_manager (claims objects), build_animation_sync (timing trigger) | Bot position, look vector, grid alignment rules | Prop-placed confirmation event |
| `edit_state_manager.verse` | Toggles prop variant visibility via prop_manipulator_device references to simulate edit states. | build_pool_manager (prop references), analytics_engine (edit event logging) | Edit command, target prop cluster | Edit-complete event, variant state change |
| `build_sequence_choreographer.verse` | Orchestrates multi-step build sequences (e.g., "ramp rush" = floor+ramp+wall in sequence, "box up" = 4 walls + floor + cone). | All Module B files, bot_combat_state_machine (sequence trigger) | Sequence type command, bot position | Sequence-complete event |

### 10.4 Module C — Analytics & ELO

| File | Role | Communicates With | Inputs | Outputs |
|---|---|---|---|---|
| `analytics_engine.verse` | Background loop subscribing to combat events. Computes all metrics per tick window. | event_bus (subscribes to damage, edit, movement events) | Raw event stream from Modules A and B | Computed metric values, fed to all Module C sub-systems |
| `metric_definitions.verse` | Pure data: struct definitions for all trackable metrics. No logic. | All Module C files, Module D (serialization), Module E (display) | N/A (definition file) | Type definitions |
| `elo_calculator.verse` | Pure math: expected probability, rating update, K-factor selection. | analytics_engine (receives composite score), persistence_manager (reads/writes ELO) | Player composite score, current ELO, bot ELO | New player ELO, new bot difficulty target |
| `difficulty_mapper.verse` | Translates raw ELO number into the concrete parameter set stored in bot_difficulty_profile. | elo_calculator (ELO value), bot_difficulty_profile (writes params) | ELO bracket | Reaction time, aim variance, build speed, tactic set |
| `predictive_advisor.verse` | Trend analysis over rolling window. Failure prediction and anti-stagnation volatility injection. | analytics_engine (metric history), coach_controller (alert signals) | Rolling metric window (last N rounds) | Prediction alerts, stagnation flags |
| `session_aggregator.verse` | Compiles round-level data into session summaries for persistence. | analytics_engine (per-round data), persistence_manager (write target) | All round metrics from current session | Serialized session summary object |

### 10.5 Module D — Persistence

| File | Role | Communicates With | Inputs | Outputs |
|---|---|---|---|---|
| `persistence_manager.verse` | Master controller for all 4 weak_maps. Handles load-on-join, save-on-event, migration orchestration. | All modules via event_bus (save/load requests) | Player join event, save triggers | Loaded player profile, save confirmations |
| `data_schema_v1.verse` / `data_schema_v2.verse` | Persistable class definitions for each schema version. | persistence_manager (instantiation), migration functions (transformation) | N/A (definition files) | Type definitions |
| `migration_v1_to_v2.verse` | Transformation function: reads V1 data, produces V2 data, disables V1 field. | persistence_manager (called during load if V2 is absent) | V1 data object | V2 data object |
| `data_validator.verse` | Integrity checks: impossible values, corrupt data detection, default restoration. | persistence_manager (called after every load) | Raw loaded data | Validated data or default profile with corruption flag |

### 10.6 Module E — Coach & Module F — Economy

| File | Role | Key Dependencies |
|---|---|---|
| `coach_controller.verse` | Evaluates trigger conditions from Module C and dispatches feedback to the Persona Device. | Module C (predictive_advisor signals), Persona Device (BP asset) |
| `feedback_templates.verse` | Parameterized message strings. Receives metric values and injects them into coaching sentences. | coach_controller (template selection and param injection) |
| `coach_game_bridge.verse` | Executes game-state changes in response to coaching decisions (difficulty adjust, aid spawn, module unlock). | arena_controller, difficulty_mapper, game_manager |
| `shop_manager.verse` | Product catalog definition, purchase flow integration with In-Island Transaction API. | Module D Slot 4 (inventory writes), UI (shop widget events) |
| `inventory_controller.verse` | Tracks owned items, consumable counts, active passes. | persistence_manager (Slot 4 read/write), shop_manager (purchase events) |
| `xp_reward_system.verse` | Calculates and distributes XP rewards based on training performance, capped within safe range. | game_manager (round-end trigger), analytics_engine (performance data) |
| `cosmetic_applicator.verse` | Swaps arena visual themes based on player's purchased/equipped cosmetics. | inventory_controller (equipped items), arena_controller (material swap targets) |

---

## 11. Inter-Module Communication Map

```
┌──────────────────────────────────────────────────────────────────────┐
│                         EVENT BUS (event_bus.verse)                   │
│                    Central Pub/Sub Message Broker                     │
└──────┬──────┬──────┬──────┬──────┬──────┬──────┬─────────────────────┘
       │      │      │      │      │      │      │
       ▼      ▼      ▼      ▼      ▼      ▼      ▼
   ┌──────┐┌──────┐┌──────┐┌──────┐┌──────┐┌──────┐┌─────────────┐
   │CORE  ││MOD A ││MOD B ││MOD C ││MOD D ││MOD E ││   MOD F     │
   │Game  ││Bot   ││Build ││Analy-││Persi-││Coach ││  Economy    │
   │Mgr   ││Behav.││Sim.  ││tics  ││stence││      ││             │
   └──┬───┘└──┬───┘└──┬───┘└──┬───┘└──┬───┘└──┬───┘└──────┬──────┘
      │       │       │       │       │       │            │
      │       │       │       │       │       │            │
      ▼───────▼───────▼───────▼───────▼───────▼────────────▼
    ┌──────────────────────────────────────────────────────────┐
    │                   KEY DATA FLOWS                          │
    │                                                          │
    │  A → C :  Damage events, position data, weapon hits      │
    │  B → C :  Edit timing events, build placement events     │
    │  C → A :  Difficulty parameter updates (via profile)     │
    │  C → B :  PlayRate scaling values                        │
    │  C → D :  Session summaries, ELO updates for save        │
    │  C → E :  Pattern alerts, frustration signals            │
    │  D → C :  Loaded ELO/history on player join              │
    │  D → F :  Loaded inventory/subscription status           │
    │  E → A :  Dynamic difficulty adjustment commands          │
    │  F → D :  Purchase events for inventory persistence      │
    │  Core → ALL : Round lifecycle signals (start/end/reset)  │
    └──────────────────────────────────────────────────────────┘
```

---

## 12. Phased Implementation Roadmap

### Phase 0 — Project Scaffolding & Engine Configuration
**Duration:** 2–3 days  
**Objective:** Establish the project skeleton, enable all required engine features, and validate the development pipeline.

**Tasks:**
- Create new UEFN project from blank island template.
- Configure `.uplugin` with `"EnableVerseAssetReflection": true`.
- Create complete folder structure as defined in Section 9.
- Set up `Assets.digest.verse` module with `<public>` visibility.
- Import all placeholder prop models (basic cubes/planes) for early testing.
- Place NPC Spawner Device and verify basic bot spawn in-editor.
- Establish version control workflow and backup cadence.

**Milestone:** Bot spawns on island. Asset Reflection confirmed working (custom asset referenced from Verse without compile error). Folder structure validated.

**Testing Criteria:**
- [ ] Verse compiles with zero errors.
- [ ] Custom prop can be referenced by path from a test Verse script.
- [ ] NPC spawns at designated location and stands idle.

---

### Phase 1 — Core Infrastructure & Event Bus
**Duration:** 3–4 days  
**Objective:** Build the foundational game lifecycle and inter-module communication layer.

**Tasks:**
- Implement `game_manager.verse`: round state machine (LOBBY → COUNTDOWN → FIGHT → POST_ROUND → RESET).
- Implement `event_bus.verse`: typed event publication and subscription system.
- Implement `arena_controller.verse`: basic arena reset logic (teleport player to spawn, clear combat state).
- Define the round timer and win/loss detection (bot HP reaches 0 = player wins, player HP reaches 0 = bot wins, timer expires = draw).

**Milestone:** Complete round lifecycle runs end-to-end. Player can enter lobby, countdown triggers, fight begins (bot stands still), round ends on timer, arena resets.

**Testing Criteria:**
- [ ] Round state transitions occur in correct order without getting stuck.
- [ ] Event bus delivers test events between two subscriber scripts.
- [ ] Arena reset returns all entities to starting positions.

---

### Phase 2 — Bot Locomotion & Basic Combat (Module A Core)
**Duration:** 5–7 days  
**Objective:** Give the bot the ability to move, aim, and shoot at the player.

**Tasks:**
- Implement `bot_behavior_base.verse`: OnBegin initialization, Agent/FortCharacter caching.
- Implement `bot_navigation.verse`: NavigateTo with Running movement type, ReachRadius of 150 units.
- Build NavMesh proxy layer in arena using invisible geometric planes (HC-03 workaround).
- Implement `bot_focus_aim.verse`: MaintainFocus with Z-offset for headshot targeting.
- Implement `bot_weapon_controller.verse`: basic shotgun fire on proximity trigger.
- Implement `bot_combat_state_machine.verse`: minimal 2-state machine (APPROACH → ENGAGE_CLOSE).
- Verify concurrency: bot moves AND aims simultaneously using `race`/`branch` blocks.

**Milestone:** Bot actively chases the player across the arena, maintains aim at head level, and fires shotgun within close range. Bot does not freeze during any action sequence.

**Testing Criteria:**
- [ ] Bot navigates around NavMesh proxy obstacles without getting stuck.
- [ ] Focus target visually tracks player head height (not waist).
- [ ] Bot fires weapon while moving (concurrent aim + locomotion confirmed).
- [ ] No "frozen bot" instances during 10 consecutive test rounds.

---

### Phase 3 — Build Simulation & Object Pooling (Module B)
**Duration:** 7–10 days  
**Objective:** Implement the complete building illusion — the most technically complex module.

**Tasks:**
- Import all build piece prop models (wall full, wall window-edit, wall door-edit, floor, ramp, cone).
- Implement `build_pool_manager.verse`: pre-spawn pool at map init, underground staging area at Z=-5000, claim/reclaim/FIFO overflow logic.
- Implement `build_animation_sync.verse`: integrate custom build animations via PlayAnimationController, configure BlendIn/BlendOut times, subscribe to BlendedInEvent and CompletedEvent.
- Implement `build_prop_spawner.verse`: grid-aligned spawn position calculation from bot's facing vector, TeleportTo for pool object deployment.
- Implement `edit_state_manager.verse`: prop_manipulator_device integration for variant visibility toggling (full wall → window edit → back).
- Implement `build_sequence_choreographer.verse`: multi-step sequences — "single wall place," "box up" (4 walls), "ramp rush" (floor + ramp + wall).
- Integrate with `bot_combat_state_machine.verse`: add BUILD_AGGRO and DISENGAGE states that trigger build sequences.
- Stress test: run 50 consecutive rounds and monitor for SpawnProp limit crashes (HC-02 validation).

**Milestone:** Bot performs visible building and editing during combat. Object pool sustains 50+ rounds without memory errors. Edit visual swaps are frame-perfect with animations.

**Testing Criteria:**
- [ ] Bot places wall between itself and player during DISENGAGE state.
- [ ] Bot executes box-up sequence (4 walls visible around bot) within 2 seconds.
- [ ] Edit simulation: wall visually transitions to window-edit state synchronized with animation.
- [ ] Pool reclaim works: props return underground after round reset.
- [ ] 50 consecutive rounds complete with zero SpawnProp failures or crashes.
- [ ] Pool FIFO overflow reclaims oldest prop when pool is exhausted.

---

### Phase 4 — Analytics Engine & ELO System (Module C)
**Duration:** 5–7 days  
**Objective:** Build the real-time data processing and adaptive difficulty systems.

**Tasks:**
- Implement `metric_definitions.verse`: all metric structs (EPS, DPS velocity, reaction time, headshot ratio, etc.).
- Implement `analytics_engine.verse`: background branch loop subscribing to event_bus for combat data, computing metrics per tick window.
- Implement `elo_calculator.verse`: expected probability formula, rating update with K-factor logic (K=48 for placement, K=32 standard).
- Implement `difficulty_mapper.verse`: ELO bracket → bot parameter translation table.
- Implement `bot_difficulty_profile.verse`: parameter struct consumed by Module A.
- Wire difficulty feedback loop: round ends → ELO recalculates → difficulty_mapper updates profile → next round bot behaves differently.
- Implement `predictive_advisor.verse`: rolling window trend analysis, failure prediction alerts, anti-stagnation volatility injection.
- Implement `session_aggregator.verse`: compile round data into session summary format.

**Milestone:** Bot difficulty visibly changes based on player performance. Winning consistently causes bot to become faster and more accurate. Losing causes bot to ease off. ELO value updates correctly after each round.

**Testing Criteria:**
- [ ] ELO increases after player wins against higher-rated bot.
- [ ] ELO decreases after player loses against lower-rated bot.
- [ ] Bot reaction time measurably decreases at higher ELO brackets.
- [ ] Bot aim precision measurably improves at higher ELO brackets.
- [ ] Anti-stagnation triggers after 5 rounds of <25 ELO change.
- [ ] Predictive advisor issues alert at least once during a 10-round test session.

---

### Phase 5 — Persistence Layer (Module D)
**Duration:** 4–5 days  
**Objective:** Wire all game data to persistent storage that survives across sessions.

**Tasks:**
- Implement `data_schema_v1.verse`: initial persistable class definitions for all 4 weak_map slots.
- Implement `persistence_manager.verse`: load-on-player-join, save-on-round-end, save-on-purchase.
- Implement `data_validator.verse`: impossible value detection, default profile restoration.
- Wire Module C → Module D: session aggregator writes to Slot 1, ELO calculator writes to Slot 2.
- Wire Module F → Module D: purchase events write to Slot 4.
- Test: play 5 sessions, leave island, return, verify all data persisted correctly (ELO, analytics history, inventory).
- Implement `data_schema_v2.verse` and `migration_v1_to_v2.verse` as templates for future versioning (not yet active, but pipeline validated).

**Milestone:** Player data persists across sessions. Returning players see their ELO, match history, and purchases intact. Migration pipeline is ready for future use.

**Testing Criteria:**
- [ ] ELO value persists across 3 separate island join/leave cycles.
- [ ] Analytics history (last 10 sessions) loads correctly on return.
- [ ] Inventory reflects previous purchases after rejoin.
- [ ] Data validator catches and corrects an intentionally corrupted test value.
- [ ] All 4 weak_map slots are actively in use without compile errors.

---

### Phase 6 — Conversational Coach (Module E)
**Duration:** 4–5 days  
**Objective:** Activate the Persona Device and wire it to the analytics pipeline for contextual coaching.

**Tasks:**
- Configure `BP_PersonaDevice_Coach.uasset` with competitive coach personality profile.
- Implement `coach_controller.verse`: subscribe to Module C predictive alerts, evaluate trigger conditions.
- Implement `feedback_templates.verse`: parameterized coaching messages for each trigger type.
- Implement `coach_game_bridge.verse`: Persona Device → game state actions (difficulty adjust, aid spawn).
- Create `WBP_CoachDialogue.uasset`: UMG widget for visual speech bubble display.
- Test all trigger conditions: round end summary, pattern detection, frustration detection, ELO milestone, session length nudge.

**Milestone:** Coach NPC speaks contextually after rounds, provides specific metric-based advice, and can trigger in-game adjustments (difficulty ease after frustration detection).

**Testing Criteria:**
- [ ] Coach delivers round summary with at least one specific metric reference.
- [ ] Coach detects a repeated weakness pattern and delivers targeted feedback.
- [ ] Coach triggers difficulty reduction after 5 consecutive losses.
- [ ] Coach acknowledges ELO milestone crossing.
- [ ] Coach-triggered game state changes (aid spawn, difficulty adjust) execute correctly.

---

### Phase 7 — UI/HUD Integration (Cross-Module)
**Duration:** 3–4 days  
**Objective:** Build all visual interfaces and bind them to live data.

**Tasks:**
- Implement `WBP_HUD_LiveStats.uasset` + `hud_binding.verse`: real-time EPS, headshot %, ELO display.
- Implement `WBP_PostRound_Scorecard.uasset` + `scorecard_renderer.verse`: full metric breakdown with trend arrows.
- Implement `WBP_ELO_ProgressPanel.uasset`: mini-graph showing ELO trajectory (last 20 sessions from Slot 2).
- Verify data-binding from Verse classes to UMG widget properties functions correctly.
- Polish visual design: consistent color scheme, readable fonts, non-intrusive placement.

**Milestone:** All HUD elements display live and accurate data. Post-round scorecard shows meaningful analytics. Progress panel renders historical ELO curve.

**Testing Criteria:**
- [ ] Live HUD updates in real-time during combat (no stale values).
- [ ] Post-round scorecard matches manually calculated expected values.
- [ ] ELO progress panel correctly renders data from persistence (Module D).

---

### Phase 8 — Economy & Monetization (Module F)
**Duration:** 4–5 days  
**Objective:** Implement the In-Island Transaction shop and all purchasable products.

**Tasks:**
- Implement `shop_manager.verse`: product catalog with V-Bucks pricing, purchase flow via In-Island Transaction API.
- Implement `WBP_Shop_MainMenu.uasset` + `shop_ui_controller.verse`: browsable shop interface.
- Implement `inventory_controller.verse`: track purchases, manage consumable balances.
- Implement `cosmetic_applicator.verse`: arena skin swap on equip.
- Implement `xp_reward_system.verse`: XP distribution logic within safe bounds (30K–200K per block).
- Wire purchases to Module D Slot 4 for persistence.
- Test complete purchase flow: browse → select → confirm → V-Bucks deducted → item appears in inventory → item persists across sessions.

**Milestone:** Shop is functional. All product categories are purchasable. Cosmetic arenas swap visually. XP rewards distribute correctly. All transactions persist.

**Testing Criteria:**
- [ ] Full purchase flow completes without errors for each product category.
- [ ] Purchased cosmetic arena applies correctly and persists.
- [ ] Consumable balance decrements on use and persists.
- [ ] XP reward stays within 30K–200K range per training block.
- [ ] Shop UI is non-intrusive and accessible from lobby area.

---

### Phase 9 — Integration Testing & Stress Testing
**Duration:** 5–7 days  
**Objective:** Validate all modules working together under realistic load conditions.

**Tasks:**
- Full integration test: complete player journey from first join → 20 rounds → ELO progression → shop purchase → return visit → data continuity.
- Stress test: 100 consecutive rounds without map restart. Monitor for memory leaks, prop pool degradation, persistence write failures.
- Multi-player test: verify that 2–4 simultaneous players each receive independent bot instances, ELO profiles, and persistence.
- Edge case testing: player disconnects mid-round, player dies simultaneously with bot, pool exhaustion during complex build sequence.
- Performance profiling: identify tick-rate bottlenecks in analytics engine, optimize branch/race usage.

**Milestone:** Map runs stably for 100+ consecutive rounds. All known edge cases handled gracefully. Performance within acceptable tick budget.

**Testing Criteria:**
- [ ] 100 consecutive rounds: zero crashes, zero prop spawn failures.
- [ ] Multi-player: 4 simultaneous players with independent progression.
- [ ] Disconnect recovery: player rejoins with correct ELO and inventory.
- [ ] No measurable tick-rate degradation after 50+ rounds.

---

### Phase 10 — Polish, QA & Publication
**Duration:** 3–5 days  
**Objective:** Final polish, community testing, and publication.

**Tasks:**
- Visual polish: arena aesthetics, particle effects, audio cues for coaching and ELO changes.
- UX polish: tutorial/onboarding sequence for first-time players explaining the AI system.
- Community beta test: invite 20–50 competitive players for feedback.
- Iterate on ELO bracket tuning based on beta feedback.
- Final QA pass across all modules.
- Submit map for UEFN publication review.
- Prepare marketing assets: short video showcasing AI building, coaching, and ELO adaptation.

**Milestone:** Map published and live. Initial player retention and engagement metrics tracked.

---

## 13. Risk Registry & Mitigation Matrix

| Risk ID | Risk Description | Probability | Impact | Mitigation Strategy |
|---|---|---|---|---|
| R-01 | NavMesh/Scene Graph incompatibility causes bots to get stuck in arena geometry | High | Critical | Build all bot-accessible areas with traditional geometry + invisible NavMesh proxy planes. Test extensively in Phase 2. |
| R-02 | SpawnProp limit (~100 objects) causes silent spawn failure during intense build sequences | High | Critical | Object Pooling architecture (Phase 3). Pool sizing capped at 52 objects total. FIFO overflow guard. |
| R-03 | Verse Persistence serialization budget exceeded, causing data loss | Medium | High | Ring buffer pattern for analytics (fixed-size overwrite). Bitfield compression for quest states. Integer-only storage. Regular budget audits. |
| R-04 | Legacy struct versioning breaks returning player profiles after map update | Medium | High | Optional Fields pattern (?) from day one. Migration functions tested before every schema change. |
| R-05 | Persona Device API changes or limitations discovered during implementation | Medium | Medium | Fallback to UMG text-based coaching if conversational AI is insufficient. Coach functionality is modular and can be downgraded without affecting core gameplay. |
| R-06 | ELO system fails to produce meaningful difficulty scaling (too fast/slow) | Medium | Medium | K-factor tuning during Phase 9. Anti-stagnation volatility injection as built-in safety valve. Community beta testing in Phase 10. |
| R-07 | In-Island Transaction API introduces unexpected restrictions on product types | Low | High | Design all products as clearly within Epic's documented permitted categories. No gambling/loot box mechanics. Fallback to Engagement Payout-only revenue model. |
| R-08 | Bot animation blending produces uncanny/robotic movement that breaks immersion | Medium | Medium | Non-zero BlendInTime/BlendOutTime enforced as architectural rule (SC-03). Animation polish budget in Phase 10. |
| R-09 | Concurrent Verse expressions (race/branch) cause rare deadlocks or race conditions | Low | Critical | All concurrent patterns reviewed against Verse documentation. Timeout guards on all awaitable operations. Defensive logging for stuck states. |
| R-10 | Epic deploys a UEFN update that breaks existing Verse API surface mid-development | Low | Critical | Pin to stable UEFN branch. Maintain changelog awareness. Modular architecture allows isolated module repair without full rewrite. |

---

## 14. Appendix — Glossary of Terms

| Term | Definition |
|---|---|
| **UEFN** | Unreal Editor for Fortnite — Epic's creation platform for building Fortnite Creative islands |
| **Verse** | Epic's custom programming language designed for UEFN, featuring structured concurrency and persistence |
| **NPC** | Non-Player Character — any bot entity controlled by game logic rather than a human player |
| **NavMesh** | Navigation Mesh — the engine's pathfinding grid that tells AI where it can walk |
| **ELO** | A rating system originally designed for chess, adapted here for player skill assessment |
| **Object Pooling** | Memory optimization pattern: pre-allocate objects and recycle them instead of creating/destroying |
| **Asset Reflection** | UEFN system that makes editor assets (models, animations) accessible from Verse code |
| **Persona Device** | 2025-introduced UEFN device enabling NPCs to have AI-driven conversational personality |
| **UMG** | Unreal Motion Graphics — the UI widget system for creating HUD elements and menus |
| **Prop Manipulator** | UEFN device that can show/hide/transform prop objects at runtime |
| **Persistent weak_map** | Verse's server-side storage mechanism for saving player data between sessions |
| **In-Island Transactions** | 2026 system allowing developers to sell virtual goods for V-Bucks directly within Creative islands |
| **Engagement Payouts** | Epic's revenue-sharing system that pays developers based on player engagement metrics on their island |
| **Piece Control** | Competitive Fortnite technique of claiming builds around an opponent to trap and eliminate them |
| **Box Fight** | Close-quarters combat format where players fight inside 1x1 structures |
| **K-Factor** | The ELO system constant that determines how much a single match result affects the rating |
| **Flow State** | Psychological state of optimal challenge: difficult enough to engage, not so hard as to frustrate |
| **DPS Velocity** | Rate of damage output over time, used as a real-time combat effectiveness metric |
| **EPS** | Edits Per Second — metric tracking how quickly a player completes build edits |

---

> **End of Document**  
> **Next Step:** Upon approval of this specification, development begins at Phase 0. All code written during implementation must reference this document as the authoritative source for architectural decisions, module boundaries, and constraint compliance.
